﻿

namespace ETicketAPI.Domain.Entities.Web
{
    public class ProductFiles:Files
    {

        public bool ShowCase { get; set; } = false;
        public ICollection<Product> Products { get; set; } = null!;
    }
}
