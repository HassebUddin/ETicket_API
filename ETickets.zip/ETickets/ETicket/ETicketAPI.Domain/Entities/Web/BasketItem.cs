﻿
using ETicketAPI.Domain.Entities.Common;

namespace ETicketAPI.Domain.Entities.Web
{
    public  class BasketItem:BaseEntity
    {

        public float Price { get; set; }
        public int  Quantity { get; set; }

        public string ProductId { get; set; } = null!;
        public Product Products { get; set; } = null!;

        public string BasketId { get; set; } = null!;
        public Basket Basekets { get; set; } = null!;


    }
}
