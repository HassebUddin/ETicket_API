﻿

using ETicketAPI.Domain.Entities.Common;

namespace ETicketAPI.Domain.Entities.Web
{
    public class Menu:BaseEntity
    {
        public string Name { get; set; } = null!;

        public ICollection<EntityEndPoint> EntityEndPoints { get; set; } = null!;
    }
}
