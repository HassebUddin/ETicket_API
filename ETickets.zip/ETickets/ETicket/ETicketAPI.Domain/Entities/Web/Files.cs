﻿

using ETicketAPI.Domain.Entities.Common;
using System.ComponentModel.DataAnnotations.Schema;

namespace ETicketAPI.Domain.Entities.Web
{
    public class Files : BaseEntity
    {
        public string FileName { get; set; } = null!;
        public string Path { get; set; } = null!;

        public string Storage { get; set; } = null!;

        [NotMapped]
        public override DateTime UpdateDate { get => base.UpdateDate; set => base.UpdateDate = value; }

      
    }
}
