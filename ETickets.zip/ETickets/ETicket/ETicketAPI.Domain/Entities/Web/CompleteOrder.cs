﻿
using ETicketAPI.Domain.Entities.Common;

namespace ETicketAPI.Domain.Entities.Web
{
   public class CompleteOrder:BaseEntity
    {

        public string OrderId { get; set; } = null!;
        public Order Orders { get; set; }
    }
}
