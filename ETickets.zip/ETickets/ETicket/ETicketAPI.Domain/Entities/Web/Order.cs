﻿using ETicketAPI.Domain.Entities.Common;

namespace ETicketAPI.Domain.Entities.Web
{
    public class Order : BaseEntity
    {
        public string OrderCode { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string Address { get; set; } = null!;


        public CompleteOrder CompleteOrders { get; set; } = null!;
        public Basket Basket { get; set; } = null!;
    }
}
