﻿using ETicketAPI.Domain.Entities.Common;

namespace ETicketAPI.Domain.Entities.Web
{
    public class Product : BaseEntity
    {
        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }



        public ICollection<BasketItem> BasketItems { get; set; } = null!;
        public ICollection<ProductFiles> ProductFiles { get; set; } = null!;
    }
}
