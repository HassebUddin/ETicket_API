﻿

using ETicketAPI.Domain.Entities.Common;
using ETicketAPI.Domain.Entities.Identity;

namespace ETicketAPI.Domain.Entities.Web
{
    public class Basket:BaseEntity
    {
        
        public string AppUserId { get; set; } = null!;
        public AppUser Users { get; set; } = null!;


        public Order Orders { get; set; } = null!;
        public ICollection<BasketItem> BasketItems { get; set; } = null!;


    }
}
