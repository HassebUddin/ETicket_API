﻿
using ETicketAPI.Domain.Entities.Common;
using ETicketAPI.Domain.Entities.Identity;
using System.ComponentModel.DataAnnotations;

namespace ETicketAPI.Domain.Entities.Web
{
    public class EntityEndPoint : BaseEntity
    {
        public EntityEndPoint()
        {
            AppRoles =new HashSet<AppRole>();
        }
        public string actionType { get; set; } = null!;
        public string httpType { get; set; } = null!;
        public string definition { get; set; } = null!;
        public string code { get; set; } = null!;

        public Menu Menus { get; set; }=null!;
  //  public string MenuId { get; set; } = null!;


        public ICollection<AppRole> AppRoles { get; set; } = null!;


    }
}
