﻿
using ETicketAPI.Domain.Entities.Common;
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Domain.Entities
{
    public class Customer:BaseEntity
    {

        public string Name { get; set; } = null!;

    }
}
