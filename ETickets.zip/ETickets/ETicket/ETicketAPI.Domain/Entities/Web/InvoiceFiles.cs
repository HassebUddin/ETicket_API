﻿

namespace ETicketAPI.Domain.Entities.Web
{
    public class InvoiceFiles:Files
    {
        public decimal Price { get; set; }
    }
}
