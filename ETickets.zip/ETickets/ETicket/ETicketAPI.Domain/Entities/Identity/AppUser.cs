﻿

using ETicketAPI.Domain.Entities.Web;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ETicketAPI.Domain.Entities.Identity
{
    public class AppUser:IdentityUser<string>
    {
        public bool Status { get; set; } = true;
        public string FullName { get; set; } = null!;
        public string Profession { get; set; } = null!;
        public string gender { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string City { get; set; } = null!;
        public string Country { get; set; } = null!;




        public ICollection<Basket> Baskets { get; set; } = null!;
        public ICollection<AppUserRole> UserRoles { get; set; } = null!;


    }
}
