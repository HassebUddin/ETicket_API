﻿
using ETicketAPI.Domain.Entities.Web;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace ETicketAPI.Domain.Entities.Identity
{
    public class AppRole:IdentityRole<string>
    {

        public ICollection<EntityEndPoint> EntityEndPoints { get; set; } = null!;
        public ICollection<AppUserRole> UserRoles { get; set; } = null!;

    }
}
