﻿

using ETicketAPI.Domain.Entities;
using ETicketAPI.Domain.Entities.Common;
using ETicketAPI.Domain.Entities.Identity;
using ETicketAPI.Domain.Entities.Web;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using System.Reflection.Emit;

namespace ETicketAPI.Persistence.Context
{
    public class ETicketAPIDbContext : IdentityDbContext<AppUser, AppRole, string>
    {
        public ETicketAPIDbContext() { }
        public ETicketAPIDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Product> products { get; set; }
        public DbSet<Customer> customers { get; set; }
        public DbSet<Order> orders { get; set; }
         public DbSet<Basket> baskets { get; set; }
        public DbSet<BasketItem> basketItems { get; set; }

        public DbSet<EntityEndPoint> entityEndPoint { get; set; }
        public DbSet<Menu> menus { get; set; }


        public DbSet<Files> files { get; set; }
        public DbSet<ProductFiles> productFiles { get; set; }
        public DbSet<InvoiceFiles> invoiceFiles { get; set; }
        public DbSet<CompleteOrder> completeOrders { get; set; }


        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
           var datas= ChangeTracker.Entries<BaseEntity>();
            foreach(var data in datas)
            {
                _ = data.State switch
                {
                    EntityState.Added => data.Entity.CreateDate = DateTime.UtcNow,
                    EntityState.Modified => data.Entity.UpdateDate = DateTime.UtcNow,
                     _ => data.Entity.CreateDate=DateTime.UtcNow,

                };
            }
                
            return await base.SaveChangesAsync(cancellationToken);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured)
                 optionsBuilder.UseSqlServer("Server=DESKTOP-P78AVG1\\SQLEXPRESS;Database=ETicket;Trusted_Connection=True;");   
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfigurationsFromAssembly(assembly:Assembly.GetExecutingAssembly());  
            base.OnModelCreating(builder);

            //define appuserrole relationship with user and role table;
            builder.Entity<AppUserRole>().HasOne(u => u.Users).WithMany(m => m.UserRoles).HasForeignKey(key => key.UserId).IsRequired();
            builder.Entity<AppUserRole>().HasOne(u => u.Roles).WithMany(m => m.UserRoles).HasForeignKey(key => key.RoleId).IsRequired();

          
            // Customize the column name for discriminator
            builder.Entity<AppUserRole>(entity =>
            {
                entity.Property<string>("Discriminator")
                      .HasDefaultValue("App UserRole");
            });

            //define order
            builder.Entity<Order>().HasKey(x => x.Id);
            
            builder.Entity<Order>().HasOne(x=>x.CompleteOrders)
                .WithOne(x=>x.Orders).HasForeignKey<CompleteOrder>(f=>f.OrderId);

            builder.Entity<Order>().Property(x=>x.OrderCode).IsUnicode();


            //define basket and order ;
            builder.Entity<Basket>().HasOne(x=>x.Orders).WithOne(x=>x.Basket).HasForeignKey<Order>(x=>x.Id);
          
            // Configure EndPoint
            builder.Entity<EntityEndPoint>()
            .HasKey(x => x.Id);


            // Optionally, configure Menu if needed
            builder.Entity<Menu>()
                .HasKey(m => m.Id);
        }
    }
}
