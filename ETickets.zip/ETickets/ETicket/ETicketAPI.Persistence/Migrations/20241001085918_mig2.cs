﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ETicketAPI.Persistence.Migrations
{
    public partial class mig2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1c9d1dba-c977-471a-98c5-a2d5f04935c1",
                column: "ConcurrencyStamp",
                value: "4c2df64d-16eb-4e69-bb5c-9a41a9c5631b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1e3672e3-8563-49a3-8024-e36d2bf3dcb0",
                column: "ConcurrencyStamp",
                value: "accfbe1f-b1dc-4106-ad7d-04c8f97632de");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e76c4fcf-4443-4cea-a649-576331c7603e",
                column: "ConcurrencyStamp",
                value: "a89e2635-7a52-48b3-9052-2538add98076");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "45121cfb-6a63-4950-9d67-68437d1bc43f",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "807b8981-9ecc-45cd-82c0-80504995eeec", "AQAAAAEAACcQAAAAEMxMuel2y6eEmHomePx8v3cCtXissLbxG93MXldc/Oasrm3ONPli+Lvan74QfIdL5A==", "00175b66-f7ad-44c5-a90d-386b09b7e690" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "7fc73959-cc3d-47d2-a017-dea6df68ae94",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "a1efbf3c-17ad-4e38-a577-e6f045dd3b22", "AQAAAAEAACcQAAAAELEdZFfx6V6zknw3YA2amVKdE6CQLIW/mal9UIdNVJGUtrmCjdbQLV+5dUtkqs9QVg==", "8a0a5e00-80d2-45a8-925e-580dac70d38a" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "8fc73959-cc3d-47d2-a017-dea6df68ae94",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "17997e34-0032-4b47-bbc8-1a2fe6ff790d", "AQAAAAEAACcQAAAAEGmEx1oqtcBKvsPCagt1N6h67I2rlEygxvV4+qoAt7Wzkz5HoU6QTYDXLAJGPutviA==", "d4c9c1ef-55ae-4eba-a85d-3f559398cb7f" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1c9d1dba-c977-471a-98c5-a2d5f04935c1",
                column: "ConcurrencyStamp",
                value: "d01ed127-8b0f-44ba-86b7-4c494fded4b9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1e3672e3-8563-49a3-8024-e36d2bf3dcb0",
                column: "ConcurrencyStamp",
                value: "e6a5ac28-a854-4308-a3f6-fa49ee3acdbf");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e76c4fcf-4443-4cea-a649-576331c7603e",
                column: "ConcurrencyStamp",
                value: "c8f49b8b-8bf4-41f5-9cf6-d7d5722f581a");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "45121cfb-6a63-4950-9d67-68437d1bc43f",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "2727ba2d-4b65-49a4-9b43-3955a1b567ee", "AQAAAAEAACcQAAAAECMhyL8WZY59pXKV8WPOOl5KAn8/5iz/7dGOfIqEZfls28bxwP4T6p4MErppzrUJ+A==", "b859e99e-32ac-4d33-bbcb-0a04e9e1f641" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "7fc73959-cc3d-47d2-a017-dea6df68ae94",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "063ef54e-6a28-40a6-9b16-c55e4e61e0f0", "AQAAAAEAACcQAAAAEGSg7kEe4Wlt+INGQ+6Q6AgzKuzcpxFu67SozMxjkDy4LKApqM5ENjW78ZCUMcu+BQ==", "bfd114b7-c811-43e7-af9e-9fa7ee9e5631" });

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "8fc73959-cc3d-47d2-a017-dea6df68ae94",
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "e4c7ee72-27fb-4f50-8638-bcce8294c1da", "AQAAAAEAACcQAAAAEB0HSiZi9+yifJnRMAQ+zhcDxPj3wTjuQ7R5PwyNyA13KMaVCSM7ytSvRWlVUHq3XA==", "bd1e5cd7-f345-4406-b0d8-dcf28e82af1e" });
        }
    }
}
