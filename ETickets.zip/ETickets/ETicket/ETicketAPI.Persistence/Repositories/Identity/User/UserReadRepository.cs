﻿

using ETicketAPI.Application.IRepositories.Identity.User;
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Identity.User
{
    public class UserReadRepository:IUserReadRepository
    {
        private readonly UserManager<AppUser> _userManager;

        public UserReadRepository(UserManager<AppUser> userManager)
        {
            _userManager = userManager;
        }

        public PagedList<AppUser> GetUsers(PaginationParam param)
        {
            var source = _userManager.Users.AsQueryable();
            return PagedList<AppUser>.Create(source,param.PageNumber, param.PageSize);
        }

        public async Task<AppUser> GetUserByIdAsync(string id)
        {
          var getUser= await _userManager.Users.FirstOrDefaultAsync(x => x.Id == id);
          if(getUser== null)
                 throw new Exception(EntityMessage.EntityNotFound("Role"));

          return getUser;   

        }
    }
}
