﻿
using ETicketAPI.Application.IRepositories.Identity.User;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Identity.User
{
    public class UserWriteRepository:IUserWriteRepository
    {
        private readonly UserManager<AppUser> _userManager; 
        public UserWriteRepository(UserManager<AppUser> userManager)
        {
            _userManager = userManager;
        }

        public async Task AddUserAsync(AppUser request)
        {
            if (await _userManager.FindByEmailAsync(request.Email)==null)
                throw new Exception(EntityMessage.EntityAlreadyExist("User"));

            await _userManager.CreateAsync(request);

        }

        public async Task UpdateUserAsync(AppUser request)
        {

            var getUser = await _userManager.Users.FirstOrDefaultAsync(x => x.Id == request.Id);
            if (getUser == null)
                throw new Exception(EntityMessage.EntityNotFound("User"));

            await _userManager.UpdateAsync(request);
        }

        public async Task DeleteUserAsync(string id)
        {
            var getUser = await _userManager.Users.FirstOrDefaultAsync(x => x.Id == id);
            if (getUser == null)
                throw new Exception(EntityMessage.EntityNotFound("User"));

            await _userManager.DeleteAsync(getUser);
        }
    }
}
