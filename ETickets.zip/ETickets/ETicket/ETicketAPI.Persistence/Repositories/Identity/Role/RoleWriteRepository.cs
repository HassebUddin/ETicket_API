﻿


using ETicketAPI.Application.IRepositories.Identity.Role;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Identity.Role
{
    class RoleWriteRepository:IRoleWriteRepository
    {
        private readonly RoleManager<AppRole> _roleManager;

        public RoleWriteRepository(RoleManager<AppRole> roleManager)
        {
            _roleManager = roleManager;
        }

        public async Task AddRoleAsync(AppRole request)
        {
            if (await _roleManager.RoleExistsAsync(request.Name))
                throw new Exception(EntityMessage.EntityAlreadyExist("Role"));

            await _roleManager.CreateAsync(request);

        }

        public async Task UpdateRoleAsync(AppRole request)
        {

            var getRole = await _roleManager.Roles.FirstOrDefaultAsync(x => x.Id == request.Id);
            if (getRole == null)
                throw new Exception(EntityMessage.EntityNotFound("Role"));

            await _roleManager.UpdateAsync(request);
        }

        public async Task DeleteRoleAsync(string id)
        {
            var getRole = await _roleManager.Roles.FirstOrDefaultAsync(x => x.Id == id);
            if (getRole == null)
                throw new Exception(EntityMessage.EntityNotFound("Role"));

            await _roleManager.DeleteAsync(getRole);
        }

    }
}
