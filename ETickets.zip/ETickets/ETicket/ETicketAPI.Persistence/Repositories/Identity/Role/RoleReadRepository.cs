﻿using ETicketAPI.Application.IRepositories.Identity.Role;
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Identity.Role
{
    public class RoleReadRepository : IRoleReadRepository
    {
        private readonly RoleManager<AppRole> _roleManager;

        public RoleReadRepository(RoleManager<AppRole> roleManager)
        {
            _roleManager = roleManager;
        }

        public PagedList<AppRole> GetRoles(PaginationParam param)
        {
            var source = _roleManager.Roles.AsQueryable();
            return PagedList<AppRole>.Create(source, param.PageNumber, param.PageSize);
        }



        public async Task<AppRole> GetRoleByIdAsync(string id)
        {
           var appRole= await _roleManager.Roles.FirstOrDefaultAsync(x => x.Id == id);
            if (appRole == null)
                throw new Exception(EntityMessage.EntityNotFound("Role"));

            return appRole;
           
        }



    }
}
