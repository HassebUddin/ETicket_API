﻿

using ETicketAPI.Application.IRepositories;
using ETicketAPI.Domain.Entities.Common;
using ETicketAPI.Persistence.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace ETicketAPI.Persistence.Repositories
{
    public class WriteRepository<T> : IWriteRepository<T> where T : BaseEntity
    {
        public ETicketAPIDbContext _context;

        public WriteRepository(ETicketAPIDbContext context)
        {
            _context = context;
        }

        public DbSet<T> Table => _context.Set<T>();

        public async Task<bool> AddAsync(T entity)
        {
           EntityEntry entry=await Table.AddAsync(entity);
          return entry.State==EntityState.Added;
    
        }

        public async Task<bool> AddRangeAsync(List<T> entity)
        {
          await Table.AddRangeAsync(entity);
            return true;
        }

        public bool Remove(T entity)
        {
           EntityEntry entry=Table.Remove(entity);
           return entry.State == EntityState.Deleted;
        }

        public bool RemoveRange(List<T> entity)
        {
          Table.RemoveRange(entity);
            return true;
        }

        public async Task<bool> RemoveAsync(string id)
        {
          var entity= await Table.FirstOrDefaultAsync(x => x.Id ==id);
            return Remove(entity!);
        }


        public bool Update(T entity)
        {
            Table.Update(entity);
            return true;
        }

        public async Task<int> SaveChangeAsync()
                       => await _context.SaveChangesAsync();

    }
}
