﻿
using ETicketAPI.Application.IRepositories.Web.File;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.File
{
    public class FileReadRepository : ReadRepository<Files>, IFileReadRepository
    {
        public FileReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
