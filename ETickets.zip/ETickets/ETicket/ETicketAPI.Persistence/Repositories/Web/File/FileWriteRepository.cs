﻿

using ETicketAPI.Application.IRepositories.Web.File;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.File
{
    public class FileWriteRepository : WriteRepository<Files>, IFileWriteRepository
    {
        public FileWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
