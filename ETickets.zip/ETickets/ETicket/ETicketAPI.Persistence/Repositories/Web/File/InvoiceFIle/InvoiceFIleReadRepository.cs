﻿

using ETicketAPI.Application.IRepositories.Web.File.InvoiceFile;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.File.InvoiceFIle
{
    public class InvoiceFIleReadRepository : ReadRepository<InvoiceFiles>, IInvoiceFileReadRepository
    {
        public InvoiceFIleReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }

    }
}
