﻿

using ETicketAPI.Application.IRepositories.Web.File.InvoiceFile;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.File.InvoiceFIle
{
    public class InvoiceFIleWriteRepository : WriteRepository<InvoiceFiles>, IInvoiceFileWriteRepository
    {
        public InvoiceFIleWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
