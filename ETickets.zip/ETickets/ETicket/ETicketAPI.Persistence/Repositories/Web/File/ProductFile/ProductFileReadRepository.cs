﻿

using ETicketAPI.Application.IRepositories.Web.File.ProductFile;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.File.ProductFile
{
    public class ProductFileReadRepository : ReadRepository<ProductFiles>, IProductFileReadRepository
    {
        public ProductFileReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
