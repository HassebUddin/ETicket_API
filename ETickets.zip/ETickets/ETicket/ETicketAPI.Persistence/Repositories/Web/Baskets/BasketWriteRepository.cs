﻿using ETicketAPI.Application.IRepositories;
using ETicketAPI.Application.IRepositories.Web.Baskets;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Baskets
{
    public class BasketWriteRepository : WriteRepository<Basket>, IBasketWriteRepository
    {
        public BasketWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
