﻿
using ETicketAPI.Application.IRepositories.Web.Baskets;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Baskets
{
    public class BasketReadRepository : ReadRepository<Basket>, IBasketReadRepository
    {
        public BasketReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
