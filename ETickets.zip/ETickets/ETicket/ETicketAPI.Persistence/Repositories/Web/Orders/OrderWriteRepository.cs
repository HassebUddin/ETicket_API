﻿using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Orders
{
    public class OrderWriteRepository : WriteRepository<Order>, IOrderWriteRepository
    {
        public OrderWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
