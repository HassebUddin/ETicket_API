﻿
using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Web.Orders
{
    public class OrderReadRepository : ReadRepository<Order>, IOrderReadRepository
    {
        public OrderReadRepository(ETicketAPIDbContext context ) : base(context)
        { }

        public PagedList<Order> GetOrder(PaginationParam param, bool AsNoTracking = true)
        {
            var query = _context.orders.Include(x=>x.CompleteOrders).Include(o => o.Basket).ThenInclude(b => b.Users)
                                       .Include(u => u.Basket).ThenInclude(b => b.BasketItems)
                                       .ThenInclude(bi => bi.Products).AsQueryable();
          
           if (!AsNoTracking)
                query.AsNoTracking();

            return PagedList<Order>.Create(query, param.PageNumber, param.PageSize);
        }
    }
}
