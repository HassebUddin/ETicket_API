﻿using ETicketAPI.Application.IRepositories.Web.Customers;
using ETicketAPI.Domain.Entities;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Customers
{
    public class CustomerWriteRepository : WriteRepository<Customer>, ICustomerWriteRepository
    {
        public CustomerWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
