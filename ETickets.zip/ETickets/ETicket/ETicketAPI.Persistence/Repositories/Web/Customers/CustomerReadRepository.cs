﻿using ETicketAPI.Application.IRepositories.Web.Customers;
using ETicketAPI.Domain.Entities;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Customers
{
    public class CustomerReadRepository : ReadRepository<Customer>, ICustomerReadRepository
    {
        public CustomerReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
