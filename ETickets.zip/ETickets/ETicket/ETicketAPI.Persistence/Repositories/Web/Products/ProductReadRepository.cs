﻿using AutoMapper.QueryableExtensions;
using ETicketAPI.Application.IRepositories;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Persistence.Repositories.Web.Products
{
    public class ProductReadRepository : ReadRepository<Product>, IProductReadRepository
    {
        private readonly IReadRepository<Product> _readRepository;
        public ProductReadRepository(ETicketAPIDbContext context, IReadRepository<Product> readRepository) : base(context)
        {
            _readRepository = readRepository;
        }

        public PagedList<Product> GetProduct(PaginationParam param, bool AsNoTracking = true)
        {
            var query = _readRepository.GetAll().Include(x=>x.ProductFiles).AsQueryable();
            if (!AsNoTracking)
                query.AsNoTracking();

            //Filter-1 sorting
//            query = query.OrderBy(x => x.CreateDate);

            return PagedList<Product>.Create(query, param.PageNumber, param.PageSize);
        }
    }
}
