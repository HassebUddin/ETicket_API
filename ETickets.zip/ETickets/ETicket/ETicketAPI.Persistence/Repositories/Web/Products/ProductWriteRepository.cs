﻿using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Products
{
    public class ProductWriteRepository : WriteRepository<Product>, IProductWriteRepository
    {
        public ProductWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
