﻿
using ETicketAPI.Application.IRepositories.Web.EndPoints;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.EndPoints
{
    public class EndPointWriteRepository : WriteRepository<EntityEndPoint>, IEndPointWriteRepository
    {
        public EndPointWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
