﻿

using ETicketAPI.Application.IRepositories.Web.CompleteOrders;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.CompleteOrders
{
    public class CompleteOrderWriteRepository : WriteRepository<CompleteOrder>, ICompleteOrderWriteRepository
    {
        public CompleteOrderWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
