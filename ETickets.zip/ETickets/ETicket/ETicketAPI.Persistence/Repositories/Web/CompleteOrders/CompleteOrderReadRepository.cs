﻿

using ETicketAPI.Application.IRepositories.Web.CompleteOrders;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.CompleteOrders
{
    internal class CompleteOrderReadRepository : ReadRepository<CompleteOrder>, ICompleteOrderReadRepository
    {
        public CompleteOrderReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
