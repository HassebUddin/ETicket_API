﻿
using ETicketAPI.Application.IRepositories.Web.Menus;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Menus
{
    public class MenuReadRepository : ReadRepository<Menu>, IMenuReadRepository
    {
        public MenuReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
