﻿
using ETicketAPI.Application.IRepositories.Web.Menus;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.Menus
{
    public class MenuWriteRepository : WriteRepository<Menu>, IMenuWriteRepository
    {
        public MenuWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
