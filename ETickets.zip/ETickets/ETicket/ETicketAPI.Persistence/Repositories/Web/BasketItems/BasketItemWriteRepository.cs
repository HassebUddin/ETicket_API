﻿

using ETicketAPI.Application.IRepositories.Web.BasketItems;
using ETicketAPI.Application.IRepositories.Web.Baskets;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.BasketItems
{
    public class BasketItemWriteRepository : WriteRepository<BasketItem>, IBasketItemWriteRepository
    {
        public BasketItemWriteRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
