﻿

using ETicketAPI.Application.IRepositories.Web.BasketItems;
using ETicketAPI.Domain.Entities.Web;
using ETicketAPI.Persistence.Context;

namespace ETicketAPI.Persistence.Repositories.Web.BasketItems
{
    public class BasketItemReadRepository : ReadRepository<BasketItem>,IBasketItemReadRepository
    {
        public BasketItemReadRepository(ETicketAPIDbContext context) : base(context)
        {
        }
    }
}
