﻿using ETicketAPI.Application.FluentValidation.Identity.Role;
using ETicketAPI.Application.FluentValidation.Identity.User;
using ETicketAPI.Application.FluentValidation.Web.Product;
using ETicketAPI.Application.IRepositories;
using ETicketAPI.Application.IRepositories.Web.File.ProductFile;
using ETicketAPI.Domain.Entities.Identity;
using ETicketAPI.Persistence.Context;
using ETicketAPI.Persistence.Repositories;
using ETicketAPI.Persistence.Repositories.Web.File.ProductFile;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace ETicketAPI.Persistence
{
    public static class ServiceExtension
    {
        public static void AddPersistence(this IServiceCollection services)
        {

            services.AddDbContext<ETicketAPIDbContext>(op => op.UseSqlServer("Server=DESKTOP-P78AVG1\\SQLEXPRESS;Database=ETicket;Trusted_Connection=True;"));


            services.AddIdentity<AppUser, AppRole>(options =>
            {
                //password requirement
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequiredLength = 0;
                options.Password.RequireLowercase = false;
                options.Password.RequireUppercase = false;
                options.Password.RequiredUniqueChars = 0;
                options.Password.RequireDigit = false;

                options.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_@.";

                ////lockout requirement
                //options.Lockout.DefaultLockoutTimeSpan=TimeSpan.FromMinutes(10);
                //options.Lockout.MaxFailedAccessAttempts = 5;

            })
                  .AddRoleManager<RoleManager<AppRole>>()
                  .AddEntityFrameworkStores<ETicketAPIDbContext>()
                  .AddDefaultTokenProviders();

            //inject idenity cookie
            services.ConfigureApplicationCookie(option =>
            {
                var cookieBuilder = new CookieBuilder();
                cookieBuilder.Name = "ETicket";

                option.Cookie = cookieBuilder;
               // option.LoginPath = new PathString("/account/login");
               //option.AccessDeniedPath = new PathString("/account/access-denied");
             });
            //token lifetime
            services.Configure<DataProtectionTokenProviderOptions>(option =>
            {
                option.TokenLifespan = TimeSpan.FromMinutes(3);
            });



            //inject reposotory
            var types = Assembly.GetExecutingAssembly().GetTypes().Where(x => x.IsClass && !x.IsAbstract && x.Name.EndsWith("Repository"));
            foreach(var item in types)
            {
                var IService = item.GetInterfaces().FirstOrDefault(x => x.Name== $"I{item.Name}");
                if (IService != null)
                    services.AddScoped(IService, item);
            }
            services.AddScoped<IProductFileWriteRepository, ProductFileWriteRepository>();



            //injcet Generic Repository
            services.AddScoped(typeof(IReadRepository<>), typeof(ReadRepository<>));


            //injcet AutoMapper
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

            //inject FluentValidation
            services.AddFluentValidationAutoValidation(op => op.DisableDataAnnotationsValidation = true);

            services.AddValidatorsFromAssemblyContaining<CreateProductValidator>();
            services.AddValidatorsFromAssemblyContaining<UpdateProductValidator>();

            services.AddValidatorsFromAssemblyContaining<RoleAddValidator>();
            services.AddValidatorsFromAssemblyContaining<RoleUpdateValidator>();

            services.AddValidatorsFromAssemblyContaining<UserAddValidator>();
            services.AddValidatorsFromAssemblyContaining<UserUpdateValidator>();





        }
    }
}
