﻿
using Microsoft.AspNetCore.SignalR;

namespace ETicketAPI.SignalR.Hubs
{
    public class ProductHub:Hub
    {

    }
}
