﻿

using ETicketAPI.Application.Abstractions.Hubs;
using ETicketAPI.SignalR.HubService;
using Microsoft.Extensions.DependencyInjection;

namespace ETicketAPI.SignalR
{
    public static class ServiceRegisteration
    {
        public static void AddSignalRService(this IServiceCollection service)
        {
            //inject hub service;
            service.AddScoped<IOrderHubService, OrderHubService>();
            service.AddScoped<IProductHubService, ProductHubService>();


            service.AddSignalR();
        }
    }
}
