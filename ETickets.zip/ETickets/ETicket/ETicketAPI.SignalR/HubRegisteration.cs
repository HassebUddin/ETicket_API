﻿
using ETicketAPI.SignalR.Hubs;
using Microsoft.AspNetCore.Builder;

namespace ETicketAPI.SignalR
{
    public static class HubRegisteration
    {
        public static void MapHub(this WebApplication application)
        {
            application.MapHub<OrderHub>("/order-hub");
            application.MapHub<ProductHub>("/product-hub");
        }
    }
}
