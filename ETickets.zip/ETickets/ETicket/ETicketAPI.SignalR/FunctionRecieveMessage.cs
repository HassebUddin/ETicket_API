﻿
namespace ETicketAPI.SignalR
{
    public static class FunctionRecieveMessage
    {
        public const string  ProductAddMessage = "reciveProductAddMessage";
        public const string OrderAddMessage = "reciveOrderAddMessage";

    }
}
