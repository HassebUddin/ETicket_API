﻿
using ETicketAPI.Application.Abstractions.Hubs;
using ETicketAPI.SignalR.Hubs;
using Microsoft.AspNetCore.SignalR;

namespace ETicketAPI.SignalR.HubService
{
    public class ProductHubService : IProductHubService
    {
        private readonly IHubContext<ProductHub> _hubContext;

        public ProductHubService(IHubContext<ProductHub> hubContext)
        {
            _hubContext = hubContext;
        }

        public async Task ProdcutAddMessage(string message)
        {
         await   _hubContext.Clients.All.SendAsync(FunctionRecieveMessage.ProductAddMessage,message);
        }
    }
}
