﻿using AutoMapper;
using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Dto.Users;
using ETicketAPI.Application.Extension;
using ETicketAPI.Application.IRepositories.Identity.User;
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Application.ViewModel.Identity.User;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserReadRepository _userReadRepository;
        private readonly IUserWriteRepository _userWriteRepository;

        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<AppRole> _roleManager;

        private readonly IMapper _mapper;
        public UserController(IUserReadRepository userReadRepository, IUserWriteRepository userWriteRepository, IMapper mapper, UserManager<AppUser> userManager, RoleManager<AppRole> roleManager)
        {
            _userReadRepository = userReadRepository;
            _userWriteRepository = userWriteRepository;
            _mapper = mapper;
            _userManager = userManager;
            _roleManager = roleManager;
        }


        // GET: api/<UserController>
        [HttpGet]
        public ActionResult<List<UserListViewModel>> GetAsync([FromQuery] PaginationParam param)
        {
            var appUser = _userReadRepository.GetUsers(param);
            //add pagination header in request
            Response.AddPaginationHeader(appUser.CurrentPage, appUser.TotalPages, appUser.PageSize, appUser.TotalCount);

            return Ok(_mapper.Map<List<UserListViewModel>>(appUser));
        }

        [HttpGet("{userId}")]
        public async Task<List<string>> GetUserRoleAsync(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user != null)
            {
                var role = await _userManager.GetRolesAsync(user);
                return role.ToList();
            }

            return null!;

        }


        [HttpPost]
        public async Task<IActionResult> GetUserRoleAsync(AssignRoleDTO request)
        {
            var user =await  _userManager.FindByIdAsync(request.UserId);
            if(user!=null)
            {
                var getRole =await _userManager.GetRolesAsync(user);
                await  _userManager.RemoveFromRolesAsync(user, getRole);

               await  _userManager.AddToRolesAsync(user, request.Role);
                return Ok();
           
            }

            return BadRequest();        
        }
    }
}
