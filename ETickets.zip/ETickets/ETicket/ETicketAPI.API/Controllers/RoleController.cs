﻿using AutoMapper;
using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Consts;
using ETicketAPI.Application.CustomAttribute;
using ETicketAPI.Application.Enums;
using ETicketAPI.Application.Extension;
using ETicketAPI.Application.IRepositories.Identity.Role;
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Application.ViewModel.Identity.Role;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly RoleManager<AppRole> _roleManager;


        private readonly IRoleReadRepository _roleReadRepository;
        private readonly IRoleWriteRepository _roleWriteRepository;

        private readonly IMapper _mapper;
        public RoleController(IRoleReadRepository roleReadRepository, IRoleWriteRepository roleWriteRepository, IMapper mapper, 
            RoleManager<AppRole> roleManager, UserManager<AppUser> userManager)
        {
            _roleReadRepository = roleReadRepository;
            _roleWriteRepository = roleWriteRepository;
            _mapper = mapper;
            _roleManager = roleManager;
            _userManager = userManager;
        }


        // GET: api/<RoleController>
        [HttpGet]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Role,
            ActionType = ActionType.Reading, Definition = "Get Role Item")]
        public ActionResult<List<RoleListViewModel>> GetAsync([FromQuery]PaginationParam param)
        {
            var appRole =  _roleReadRepository.GetRoles(param);
            //add pagination header in request
            Response.AddPaginationHeader(appRole.CurrentPage, appRole.TotalPages, appRole.PageSize, appRole.TotalCount);

            return Ok(_mapper.Map<List<RoleListViewModel>>(appRole));
        }
         
        // GET api/<RoleController>/5
        [HttpGet("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Role,
            ActionType = ActionType.Reading, Definition = "GetById Role Item")]
        public async Task<ActionResult<RoleListViewModel>> GetAsync(string id)
        {
            var appRole = await _roleReadRepository.GetRoleByIdAsync(id);
            return Ok(_mapper.Map<RoleListViewModel>(appRole));
        }

        // POST api/<RoleController>
        [HttpPost]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Role,
            ActionType = ActionType.Writting, Definition = "Add Role Item")]
        public async Task<ActionResult> PostAsync([FromBody] RoleCreateViewModel request)
        {
            var appRole = _mapper.Map<AppRole>(request);
            await _roleWriteRepository.AddRoleAsync(appRole);

            return Ok(ApiResponseMessage.SuccessResponse("add"));
        }

        // PUT api/<RoleController>/5
        [HttpPut("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Role,
            ActionType = ActionType.Updating, Definition = "Update Role Item")]
        public ActionResult Put(RoleUpdateViewModel request)
        {

            var appRole = _mapper.Map<AppRole>(request);
            _roleWriteRepository.UpdateRoleAsync(appRole);
            return Ok(ApiResponseMessage.SuccessResponse("update"));
        }

        // DELETE api/<RoleController>/5
        [HttpDelete("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Role,
            ActionType = ActionType.Deleting, Definition = "Delete Role Item")]
        public async Task<ActionResult> Delete(string id)
        {
            await _roleWriteRepository.DeleteRoleAsync(id);
            return Ok(ApiResponseMessage.SuccessResponse("delete"));
        }


       
    }
}
