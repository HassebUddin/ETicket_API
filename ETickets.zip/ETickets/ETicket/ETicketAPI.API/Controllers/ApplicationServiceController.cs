﻿

using ETicketAPI.Application.Abstractions.Service.Configutration;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]

    public class ApplicationServiceController : ControllerBase
    {
        private readonly IApplicationService _applicationService;

        public ApplicationServiceController(IApplicationService applicationService)
        {
            _applicationService = applicationService;
        }

        [HttpGet]
        public ActionResult GetAuthorizationDefinitionEndPoints()
        {
            var response=_applicationService.GetAuthorizationDefinionEndPoints(typeof(Program));   
            return Ok(response);
        }
    }
}
