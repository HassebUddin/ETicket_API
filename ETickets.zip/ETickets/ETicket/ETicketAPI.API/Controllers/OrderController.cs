﻿using AutoMapper;
using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Consts;
using ETicketAPI.Application.CustomAttribute;
using ETicketAPI.Application.Dto;
using ETicketAPI.Application.Enums;
using ETicketAPI.Application.Extension;
using ETicketAPI.Application.Features.Command.Orders.CompleteOrders;
using ETicketAPI.Application.Features.Command.Orders.CreateOrder;
using ETicketAPI.Application.Features.Command.Orders.RemoveOrder;
using ETicketAPI.Application.Features.Queries.Orders.GetOrder;
using ETicketAPI.Application.Features.Queries.Orders.GetOrderById;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;


namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IMediator _mediatr;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public OrderController(IMediator mediatr, IHttpContextAccessor httpContextAccessor)
        {
            _mediatr = mediatr;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Order,
            ActionType = ActionType.Reading, Definition = "Get OrderItem")]
        public async Task<ActionResult> GetOrder([FromQuery] GetOrderQueryRequest request)
        {
            List<GetOrderQueryResponse> response = await _mediatr.Send(request);

            // Add pagination into header
            var paginatedSession = _httpContextAccessor.HttpContext!.Session.GetString("paginationContent");
            var pagedListDto = JsonConvert.DeserializeObject<PagedListDto<Order>>(paginatedSession);

            Response.AddPaginationHeader(pagedListDto.CurrentPage, pagedListDto.TotalPages, pagedListDto.PageSize,
              pagedListDto.TotalCount);


            return Ok(response);
        }


        [HttpPost]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Order,
            ActionType = ActionType.Writting, Definition = "Add OrderItem")]
        public async Task<ActionResult> CreateOrder(CreateOrderCommandRequest request)
        {
            CreateOrderCommandResponse response = await _mediatr.Send(request);
            return Ok(response);
        }

        [HttpDelete("{OrderId}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Order,
            ActionType = ActionType.Deleting, Definition = "Delete OrderItem")]
        public async Task<ActionResult> DeleteOrder([FromRoute] RemoveOrderCommandRequest request)
        {
            RemoveOrderCommandResponse response = await _mediatr.Send(request);
            return Ok(response);
        }


        [HttpGet("{OrderId}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Order,
            ActionType = ActionType.Reading, Definition = "GetById OrderItem")]
        public async Task<ActionResult> GetOrderById([FromRoute] GetOrderByIdQueryRequest request)
        {
            GetOrderByIdQueryRepsonse response = await _mediatr.Send(request);
            return Ok(response);

        }


        [HttpGet("{OrderId}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Order,
            ActionType = ActionType.Writting, Definition = "Confirm Order")]
        public async Task<ActionResult> ConfirmOrder([FromRoute] CompleteOrderCommandRequest request)
        {
           CompleteOrderCommandResponse response = await _mediatr.Send(request);
            return Ok(response);

        }


    }
}