﻿
using AutoMapper;

using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Consts;
using ETicketAPI.Application.CustomAttribute;
using ETicketAPI.Application.Dto;
using ETicketAPI.Application.Enums;
using ETicketAPI.Application.Extension;
using ETicketAPI.Application.Features.Command.ProductImages.ChangeShowCaseImage;
using ETicketAPI.Application.Features.Command.ProductImages.RemoveProductImage;
using ETicketAPI.Application.Features.Command.ProductImages.UploadProductImage;
using ETicketAPI.Application.Features.Command.Products.CreateProduct;
using ETicketAPI.Application.Features.Command.Products.RemoveProduct;
using ETicketAPI.Application.Features.Command.Products.UpdateProduct;
using ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage;
using ETicketAPI.Application.Features.Queries.Products.GeProductById;
using ETicketAPI.Application.Features.Queries.Products.GetProduct;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;



namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IMediator _mediatr;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ProductController(IMediator mediatr, IHttpContextAccessor httpContextAccessor)
        {
            _mediatr = mediatr;
            _httpContextAccessor = httpContextAccessor;
        }





        // GET: api/<Product Controller>
        [HttpGet]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Reading, Definition = "Get Product")]
        public async Task<ActionResult> GetAsync([FromQuery] GetProductQueryRequest request) 
        {

            var response=await _mediatr.Send(request);



            // Add pagination into header
            var paginatedSession = _httpContextAccessor.HttpContext!.Session.GetString("paginationContent");
            var pagedListDto = JsonConvert.DeserializeObject<PagedListDto<Product>>(paginatedSession);

            Response.AddPaginationHeader(pagedListDto.CurrentPage, pagedListDto.TotalPages, pagedListDto.PageSize,
              pagedListDto.TotalCount);


            return Ok(response);
        }




        // GET api/<ProductController>/5
        [HttpGet("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Reading, Definition = "GetById Product")]
        public async Task<ActionResult> GetAsync([FromRoute] GeProductByIdQueryRequest request)
        {
            try
            {
                GeProductByIdQueryResponse resposne = await _mediatr.Send(request);
                return Ok(resposne);

            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }
        } 


        // POST api/<ProductController>
        [HttpPost]
          [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Writting, Definition = "Add Product")]
        public async Task<ActionResult> PostAsync(CreateProductCommandRequest request)
        {


            try
            {
                CreateProductCommandResponse resposne = await _mediatr.Send(request);
                return Ok(ApiResponseMessage.SuccessResponse("Add"));
            }
            catch(Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }



        }

        // PUT api/<ProductController>/5
        [HttpPut]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Updating, Definition = "Update Product")]
        public async Task<ActionResult> PutAsync(UpdateProductCommandRequest request)
        {
             try
            {

                UpdateProductCommandResponse resposne = await _mediatr.Send(request);
                return Ok(ApiResponseMessage.SuccessResponse("Update"));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Deleting, Definition = "Delete Product")]
        public async Task<ActionResult> DeleteAsync([FromRoute] RemoveProductCommandRequest request)
        {
            try
            {
                RemoveProductCommandResponse resposne = await _mediatr.Send(request);
                return Ok(ApiResponseMessage.SuccessResponse("Delete"));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }

        }

 
        
        //Uplaod Product Image Base Crud
        
        
        [HttpPost]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Writting, Definition = "Upload ProductImage")]
        public async Task<ActionResult> Upload([FromQuery] UploadProductImageCommandRequest request)
        {
            try
            {
                request.IFormFile =Request.Form.Files;
                UploadProductImageCommandResponse resposne = await _mediatr.Send(request);
                return Ok(ApiResponseMessage.CustomResponse("Image upload successfully"));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }

        }


        [HttpGet("{id}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
        ActionType = ActionType.Reading, Definition = "GetById ProdcutImage")]
        public async Task<ActionResult> GetProductImages([FromRoute] GetProductImageQueryRequest request)
        {
            try
            {
               
                List<GetProductImageQueryResponse> resposne = await _mediatr.Send(request);
                return Ok(resposne);
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }
        }


        [HttpDelete("{productId}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Deleting, Definition = "Delete ProductImage")]
        public async Task<ActionResult> DeleteProductImage([FromRoute] RemoveProductImageCommandRequest request, [FromQuery] string imageId)
        {

            try
            {
                request.imageId = imageId;
                RemoveProductImageCommandResponse resposne = await _mediatr.Send(request);
                return Ok(ApiResponseMessage.CustomResponse("Image deleted siccessfully"));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponseMessage.BadResponse(ex.Message));
            }

        }


        [HttpPut]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Product,
            ActionType = ActionType.Updating, Definition = "SetProductImage ")]
        public async Task<ActionResult> ChangeShowCaseImage([FromQuery] ChangeShowCaseImageCommandRequest request)
        {

            ChangeShowCaseImageResponse response =await _mediatr.Send(request);
            return Ok(response);

        }



        }
    }
