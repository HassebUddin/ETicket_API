﻿
using AutoMapper;
using ETicketAPI.Application.ViewModel.Web.Product;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers.BaseControllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
       



    }
}
