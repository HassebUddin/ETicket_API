﻿using ETicketAPI.Application.Features.Command.AuthorizationEndPoint;
using ETicketAPI.Application.Features.Queries.AuthorizationEndPoint.GetRoleToEndPoint;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthorizationEndPointController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AuthorizationEndPointController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetRoleToEndPoint([FromQuery] GetRoleToEndPointQueryRequest request)
        {
            GetRoleToEndPointQueryResponse response=  await  _mediator.Send(request);
            return Ok(response);    
        }


        [HttpPost]
        public async Task<IActionResult> AssignRoleEndPoint([FromBody]AuthorizationEndPointCommandRequest request)
        {
            request.Type =typeof(Program);
            AuthorizationEndPointCommandResponse response=   await _mediator.Send(request);
            return Ok();    
        }
    }
}
