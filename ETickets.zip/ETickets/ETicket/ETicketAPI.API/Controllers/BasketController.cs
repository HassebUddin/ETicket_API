﻿using AutoMapper;
using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Consts;
using ETicketAPI.Application.CustomAttribute;
using ETicketAPI.Application.Dto;
using ETicketAPI.Application.Enums;
using ETicketAPI.Application.Extension;
using ETicketAPI.Application.Features.Command.BasketItems.AddBasketItem;
using ETicketAPI.Application.Features.Command.BasketItems.RemoveBasketItem;
using ETicketAPI.Application.Features.Command.BasketItems.UpdateBasketItem;
using ETicketAPI.Application.Features.Queries.BasketItems.GetBasketItem;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace ETicketAPI.API.Controllers
{
    public class BasketController : BaseController
    {
        private readonly IMediator _mediator;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public BasketController( IMediator mediator, IHttpContextAccessor httpContextAccessor) 
        {
            _mediator = mediator;
           _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AuthorizationDefinition(Menu =AuthorizationDefinitionConstant.Basket,
            ActionType =ActionType.Reading,Definition ="Get BasketItem")]
        public async Task<ActionResult> GetBasketItem([FromQuery]GetBasketItemQueryRequest request)
        
        {
            var response=await  _mediator.Send(request);
            return Ok(response);    
        }


        [HttpPost]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Basket,
            ActionType = ActionType.Writting, Definition = "Add BasketItem")]
        public async Task<ActionResult> AddBasket(AddBasketItemCommandRequest request)
        {
            AddBasketItemCommandResponse response = await _mediator.Send(request);
            return Ok(response);

        }

        [HttpPut]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Basket,
            ActionType = ActionType.Updating, Definition = "Update BasketItem")]
        public async Task<ActionResult> UpdateBasket(UpdateBasketItemCommandRequest request)
        {
            UpdateBasketItemCommandResponse response = await _mediator.Send(request);
            return Ok(response);
        }

        [HttpDelete("{BasketItemId}")]
        [AuthorizationDefinition(Menu = AuthorizationDefinitionConstant.Basket,
            ActionType = ActionType.Deleting, Definition = "Delete BasketItem")]
        public async Task<ActionResult> RemoveBasket([FromRoute]RemoveBasketItemRequest request)
        {
           RemoveBasketItemResponse  response = await _mediator.Send(request);
            return Ok(response);
        }
    }
}
