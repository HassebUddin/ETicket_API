﻿using AutoMapper;
using ETicketAPI.API.Controllers.BaseControllers;
using ETicketAPI.Application.Features.Command.Accounts.Login;
using ETicketAPI.Application.Features.Command.Accounts.Register;
using ETicketAPI.Application.Messages;
using MediatR;
using Microsoft.AspNetCore.Mvc;


namespace ETicketAPI.API.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AccountController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginCommandRequest request)
        {
            LoginCommandResponse response=await _mediator.Send(request);
            return Ok(ApiResponseMessage.SuccessResponse("Login"));    
        }

        [HttpPost]
        public async Task<ActionResult> Reister(RegisterCommandRequest request)
        {
            RegisterCommandResponse response = await _mediator.Send(request);
            return Ok(ApiResponseMessage.SuccessResponse("Register"));
        }

    }
}
