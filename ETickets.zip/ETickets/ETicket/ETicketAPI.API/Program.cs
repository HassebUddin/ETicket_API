
using ETicketAPI.API.Extensions;
using ETicketAPI.Application;
using ETicketAPI.Infrastructure;
using ETicketAPI.Infrastructure.Filters;
using ETicketAPI.Infrastructure.Service.Storage.Local;
using ETicketAPI.Persistence;
using ETicketAPI.SignalR;
using System.Security.Cryptography;

var builder = WebApplication.CreateBuilder(args);




// Add All Class Libraray to the container.
builder.Services.AddPersistence();
builder.Services.AddInfrastructure();
builder.Services.AddApplicationService();
builder.Services.AddSignalRService();


//builder.Services.AddStorage(StorageType.local);
builder.Services.AddStorage<LocalStorage>();

//inject session
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();


// Add session services
builder.Services.AddDistributedMemoryCache(); // Adds a default in-memory implementation of IDistributedCache
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
    options.Cookie.HttpOnly = true; // Make the session cookie HttpOnly
    options.Cookie.IsEssential = true; // Make the session cookie essential
});

//inject custome Filter
builder.Services.AddControllers(op=>op.Filters.Add<ValidationFilters>())
    .ConfigureApiBehaviorOptions(op=>op.SuppressModelStateInvalidFilter=true);




//add cors
builder.Services.AddCors(cor => cor.AddPolicy
("EnableCors", policy => { policy.AllowAnyMethod().AllowAnyHeader().WithOrigins("http://localhost:4200").AllowCredentials(); }));



// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();



// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.ConfigureExceptionHandler<Program>(app.Services.GetRequiredService<ILogger<Program>>());
app.UseCors("EnableCors");  

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseSession();

app.UseAuthentication();
app.UseAuthorization();


app.MapHub();
app.MapControllers();

app.Run();
