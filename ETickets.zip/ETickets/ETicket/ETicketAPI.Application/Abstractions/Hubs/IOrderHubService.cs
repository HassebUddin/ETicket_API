﻿

namespace ETicketAPI.Application.Abstractions.Hubs
{
    public interface IOrderHubService
    {
        void OrderAddMessage(string message);
    }
}
