﻿

namespace ETicketAPI.Application.Abstractions.Hubs
{
    public interface IProductHubService
    {
        Task ProdcutAddMessage(string mesasge);
    }
}
