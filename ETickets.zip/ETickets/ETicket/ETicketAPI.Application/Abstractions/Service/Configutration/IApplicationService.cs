﻿
using ETicketAPI.Application.Dto.Configurations;

namespace ETicketAPI.Application.Abstractions.Service.Configutration
{
    public interface IApplicationService
    {
        List<Menu> GetAuthorizationDefinionEndPoints(Type type);
    }
}
