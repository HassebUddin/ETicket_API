﻿
using ETicketAPI.Application.ViewModel.Account;

namespace ETicketAPI.Application.Abstractions.Service
{
    public interface IAccountService
    {

        Task RegisterAsync(RegisterViewModel register);
        Task LoginAsync(LoginViewModel login);

    }
}
