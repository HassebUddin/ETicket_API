﻿
using ETicketAPI.Application.ViewModel.Web.Basket;
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.Abstractions.Service
{
    public interface IBasketService
    {


        Task<List<BasketItem>> GetBasketItemAsync();
        Task AddItemToBasketAsync(CreateBasketViewModel basketItem);
        Task UpateBasketItemAsync(UpdateBasketViewModel basketItem);
        Task RemoveBasketItemAsync(string basketItemId);



        public Basket GetActiveUserBasket { get; }


    }
}   
