﻿using ETicketAPI.Application.Dto.Orders;

namespace ETicketAPI.Application.Abstractions.Service
{
    public interface IOrderService
    {
        Task CreateOrder(CreateOrder order);
        Task<List<ListOrder>> GetOrders();
        
    }
}
