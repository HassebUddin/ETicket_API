﻿

using System.Globalization;

namespace ETicketAPI.Application.Abstractions.Service
{
    public interface IAuthorizationEndPointService
    {
        Task AssignRoleEndPointAsync(string[] role, string menu, string code, Type type);
        Task<List<string>> GetRoleToEndPointAsync(string menu, string code);
    }
}
