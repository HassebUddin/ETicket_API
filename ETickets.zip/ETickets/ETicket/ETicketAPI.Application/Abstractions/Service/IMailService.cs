﻿

namespace ETicketAPI.Application.Abstractions.Service
{
    public  interface IMailService
    {
        Task SendMailAsync(string[] tos, string password, string body, string subject, bool bodyHtml = true);
       Task SendMailAsync(string to, string password, string body, string subject, bool bodyHtml = true);
    }
}
