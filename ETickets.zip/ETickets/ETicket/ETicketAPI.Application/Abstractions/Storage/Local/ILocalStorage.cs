﻿using ETicketAPI.Application.Abstractions.Storage;

namespace ETicketAPI.Application.Abstractions.Storage.Local
{
    public interface ILocalStorage : IStorage
    {
    }
}
