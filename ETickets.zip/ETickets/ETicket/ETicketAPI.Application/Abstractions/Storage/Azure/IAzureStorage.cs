﻿using ETicketAPI.Application.Abstractions.Storage;

namespace ETicketAPI.Application.Abstractions.Storage.Azure
{
    public interface IAzureStorage : IStorage
    {

    }
}
