﻿

using ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage;

namespace ETicketAPI.Application.Features.Queries.Products.GetProduct
{
    public class GetProductQueryResponse
    {
        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }
        public string ImagePath { get; set; } = null!;
        public string Id { get; set; } = null!;


        public List<GetProductImageQueryResponse> productFiles { get; set; }=null!;
    }
}
