﻿

using AutoMapper;
using ETicketAPI.Application.Dto;
using ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;


namespace ETicketAPI.Application.Features.Queries.Products.GetProduct
{
    public class GetProductQueryHandler : IRequestHandler<GetProductQueryRequest, List<GetProductQueryResponse>>
    {
        private readonly IProductReadRepository _productReadRepository;

        private readonly IMapper _mapper;
        private readonly ILogger<GetProductQueryHandler> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public GetProductQueryHandler(IProductReadRepository productReadRepository, IMapper mapper, ILogger<GetProductQueryHandler> logger, IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _productReadRepository = productReadRepository;
            _mapper = mapper;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        public async Task<List<GetProductQueryResponse>> Handle(GetProductQueryRequest request, CancellationToken cancellationToken)
        {
            
            _logger.LogInformation("some thinf");
            var pagiationParam = new PaginationParam { PageNumber = request.PageNumber, PageSize = request.PageSize };
            var pagedListProducts = _productReadRepository.GetProduct(pagiationParam);
            var pagedListDto = new PagedListDto<Product>
            {
                CurrentPage = pagedListProducts.CurrentPage,
                TotalPages = pagedListProducts.TotalPages,
                PageSize = pagedListProducts.PageSize,
                TotalCount = pagedListProducts.TotalCount,
                Items = pagedListProducts.ToList()
            };

            _httpContextAccessor.HttpContext!.Session.SetString("paginationContent", JsonConvert.SerializeObject(pagedListDto, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            }));

           
            return pagedListProducts.Select(x => new GetProductQueryResponse
            {
                Id=x.Id,
                Name = x.Name,
                Price = x.Price,
                Stock = x.Stock,
                ImagePath = x.ProductFiles
        .Where(file => file.ShowCase)
        .Select(file => $"{_configuration["BaseStorage"]}\\{file.Path}\\{file.FileName}") // Adjust file property if necessary
        .FirstOrDefault(),
                productFiles =_mapper.Map<List<GetProductImageQueryResponse>>(x.ProductFiles)

            }).ToList();
            

            
        }
    }
}
