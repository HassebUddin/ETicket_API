﻿

namespace ETicketAPI.Application.Features.Queries.Products.GeProductById
{
    public class GeProductByIdQueryResponse
    {
        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }
    }
}
