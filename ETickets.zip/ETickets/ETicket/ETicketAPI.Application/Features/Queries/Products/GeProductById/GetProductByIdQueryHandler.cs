﻿

using AutoMapper;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using MediatR;

namespace ETicketAPI.Application.Features.Queries.Products.GeProductById
{
   
    public class GetProductByIdQueryHandler : IRequestHandler<GeProductByIdQueryRequest, GeProductByIdQueryResponse>
    {
        private readonly IProductReadRepository _productReadRepository;

        private readonly IMapper _mapper;

        public GetProductByIdQueryHandler(IProductReadRepository productReadRepository, IMapper mapper)
        {
            _productReadRepository = productReadRepository;
            _mapper = mapper;
        }

        public async Task<GeProductByIdQueryResponse> Handle(GeProductByIdQueryRequest request, CancellationToken cancellationToken)
        {
            var product=await _productReadRepository.GetByIdAsync(request.id, false);
            if (product == null)
                throw new Exception(EntityMessage.EntityNotFound("Product"));

            return _mapper.Map<GeProductByIdQueryResponse>(product);

        }
    }
}
