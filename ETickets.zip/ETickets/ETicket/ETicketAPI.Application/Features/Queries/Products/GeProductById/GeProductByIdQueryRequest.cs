﻿
using MediatR;

namespace ETicketAPI.Application.Features.Queries.Products.GeProductById
{
    public class GeProductByIdQueryRequest:IRequest<GeProductByIdQueryResponse>
    {
        public string id { get; set; } = null!;
    }
}
