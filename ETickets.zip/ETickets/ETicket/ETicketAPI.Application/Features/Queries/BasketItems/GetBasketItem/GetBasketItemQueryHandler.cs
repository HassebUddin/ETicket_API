﻿using ETicketAPI.Application.Abstractions.Service;
using MediatR;

namespace ETicketAPI.Application.Features.Queries.BasketItems.GetBasketItem
{
    public class GetBasketItemQueryHandler : IRequestHandler<GetBasketItemQueryRequest, List<GetBasketItemQueryResponse>>
    {
        private readonly IBasketService _basketService;

        public GetBasketItemQueryHandler(IBasketService basketService)
        {
            _basketService = basketService;
        }

        public  async Task<List<GetBasketItemQueryResponse>> Handle(GetBasketItemQueryRequest request, CancellationToken cancellationToken)
        {
            var basketItems = await _basketService.GetBasketItemAsync();
            return basketItems.Select(x => new GetBasketItemQueryResponse()
            {
               
                Quantity = x.Quantity,
                Price = x.Products.Price,
                Name = x.Products.Name,
                BasketItemId = x.Id
            }).ToList();
        }
    }
}
