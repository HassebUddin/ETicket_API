﻿using MediatR;

namespace ETicketAPI.Application.Features.Queries.BasketItems.GetBasketItem
{
    public class GetBasketItemQueryRequest : IRequest<List<GetBasketItemQueryResponse>>
    {
    }
}
