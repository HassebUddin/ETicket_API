﻿

namespace ETicketAPI.Application.Features.Queries.BasketItems.GetBasketItem
{
    public class GetBasketItemQueryResponse
    {
        public string Name { get; set; } = null!;
        public int Quantity { get; set; }
        public string BasketItemId { get; set;} = null!;
        public float Price { get; set; }

    }
}
