﻿

using AutoMapper;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage
{
    public class GetProductImageHanlder : IRequestHandler<GetProductImageQueryRequest,List<GetProductImageQueryResponse>>
    {
        private readonly IProductReadRepository _productReadRepository;

        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;

        public GetProductImageHanlder(IProductReadRepository productReadRepository, IConfiguration configuration, IMapper mapper)
        {
            _productReadRepository = productReadRepository;
            _configuration = configuration;
            _mapper = mapper;
        }

        public async Task<List<GetProductImageQueryResponse>> Handle(GetProductImageQueryRequest request, CancellationToken cancellationToken)
        {
            var product = await _productReadRepository.Table.Include(x => x.ProductFiles).FirstOrDefaultAsync(x => x.Id == request.id);
            if (product == null)
                throw new Exception(EntityMessage.EntityNotFound("Product"));

            return product!.ProductFiles.Select(x => new GetProductImageQueryResponse
            {

                ShowCase=x.ShowCase,
                Path = $"{_configuration["BaseStorage"]}\\{x.Path}",
                FileName = x.FileName,
                Id = x.Id
            }).ToList();

        }
    }
}
