﻿

using MediatR;

namespace ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage
{
    public class GetProductImageQueryRequest:IRequest<List<GetProductImageQueryResponse>>
    {
        public string id { get; set; } = null!;
    }
}
