﻿

namespace ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage
{
    public class GetProductImageQueryResponse
    {
        public string Path { get; set; } = null!;
        public string FileName { get; set; } = null!;
        public string Id { get; set; } = null!;
        public bool  ShowCase { get; set; }

    }
}
