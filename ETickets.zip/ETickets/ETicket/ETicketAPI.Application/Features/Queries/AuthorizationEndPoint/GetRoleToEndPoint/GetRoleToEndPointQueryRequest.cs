﻿
using MediatR;

namespace ETicketAPI.Application.Features.Queries.AuthorizationEndPoint.GetRoleToEndPoint
{
    public class GetRoleToEndPointQueryRequest:IRequest<GetRoleToEndPointQueryResponse>
    {
        public string menu { get; set; } = null!;
        public string code { get; set; } = null!;

    }
}
