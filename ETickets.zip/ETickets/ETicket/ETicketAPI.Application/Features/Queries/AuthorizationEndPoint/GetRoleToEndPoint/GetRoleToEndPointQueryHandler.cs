﻿

using ETicketAPI.Application.Abstractions.Service;
using MediatR;

namespace ETicketAPI.Application.Features.Queries.AuthorizationEndPoint.GetRoleToEndPoint
{
    public class GetRoleToEndPointQueryHandler : IRequestHandler<GetRoleToEndPointQueryRequest, GetRoleToEndPointQueryResponse>
    {
        private readonly IAuthorizationEndPointService  _authorizationEndPointService;

        public GetRoleToEndPointQueryHandler(IAuthorizationEndPointService authorizationEndPointService)
        {
            _authorizationEndPointService = authorizationEndPointService;
        }

        public async Task<GetRoleToEndPointQueryResponse> Handle(GetRoleToEndPointQueryRequest request, CancellationToken cancellationToken)
        {
            var datas=   await _authorizationEndPointService.GetRoleToEndPointAsync(request.menu,request.code);
            return new()
            {
                Role= datas
            };

        }
    }
}
