﻿

namespace ETicketAPI.Application.Features.Queries.AuthorizationEndPoint.GetRoleToEndPoint
{
    public class GetRoleToEndPointQueryResponse
    {
        public List<string> Role { get; set; } = null!;
    }
}
