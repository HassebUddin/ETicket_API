﻿

using MediatR;

namespace ETicketAPI.Application.Features.Queries.Orders.GetOrderById
{
  
    public  class GetOrderByIdQueryRequest:IRequest<GetOrderByIdQueryRepsonse>
    {
        public string OrderId { get; set; } = null!;
    }
}
