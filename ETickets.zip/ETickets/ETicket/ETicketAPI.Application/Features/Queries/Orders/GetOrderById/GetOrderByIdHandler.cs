﻿

using ETicketAPI.Application.Features.Queries.Orders.GetOrder;
using ETicketAPI.Application.IRepositories.Web.CompleteOrders;
using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.EntityFrameworkCore;


namespace ETicketAPI.Application.Features.Queries.Orders.GetOrderById
{
    public class GetOrderByIdHandler : IRequestHandler<GetOrderByIdQueryRequest, GetOrderByIdQueryRepsonse>
    {
        private readonly IOrderReadRepository _orderReadRepository;
        private readonly ICompleteOrderReadRepository _completeOrderReadRepository;

        public GetOrderByIdHandler(IOrderReadRepository orderReadRepository, ICompleteOrderReadRepository completeOrderReadRepository)
        {
            _orderReadRepository = orderReadRepository;
            _completeOrderReadRepository = completeOrderReadRepository;
        }

        public async Task<GetOrderByIdQueryRepsonse> Handle(GetOrderByIdQueryRequest request, CancellationToken cancellationToken)
        {
            var data = await _orderReadRepository.Table.Include(b => b.Basket).ThenInclude(b => b.BasketItems)
                    .ThenInclude(bi => bi.Products).ToListAsync();
           
            var CompleteOrderResult = await _completeOrderReadRepository.GetAll().ToListAsync();

            var result = data
         .GroupJoin(
             CompleteOrderResult,
             o => o.Id,
             c => c.OrderId,
             (o, cs) => new
             {
                 Order = o,
                 CompleteOrders = cs
             })
         .SelectMany(
             x => x.CompleteOrders.DefaultIfEmpty(), // Ensure the sequence is not empty
             (x, c) => new
             {
                 Id = x.Order.Id,
                 CreateDate = x.Order.CreateDate,
                 OrderCode = x.Order.OrderCode, // Fix the property reference here 
                 Address = x.Order.Address, // Fix the property reference here
                 Description = x.Order.Description, // Fix the property reference here
                 Basket = x.Order.Basket,
                 CompleteOrder = c == null?true:false // If there is no complete order, then `CompleteOrder` should be true
             }
         ).FirstOrDefault(o=>o.Id==request.OrderId);
         if(result==null)
              throw new Exception(EntityMessage.EntityNotFound("Order"));

            return new()
            {
                CompleteOrder = result.CompleteOrder,
                Id = result.Id,
                CreateDate = result.CreateDate,
                OrderCode = result.OrderCode,
                Address = result.Address,
                Description = result.Description,
                BasketItem = result.Basket.BasketItems.Select(bi => new
                {
                    bi.Quantity,
                    bi.Products.Name,
                    bi.Products.Price

                })

            };
        


           
        }
    }
}
