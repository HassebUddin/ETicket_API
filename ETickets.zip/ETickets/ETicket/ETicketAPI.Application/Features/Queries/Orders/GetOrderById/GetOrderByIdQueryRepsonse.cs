﻿

using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.Features.Queries.Orders.GetOrderById
{
    public class GetOrderByIdQueryRepsonse
    {
        public string Id { get; set; } = null!;
        public DateTime CreateDate { get; set; }
        public string OrderCode { get; set; } = null!;
        public object BasketItem { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string Description { get; set; } = null!;
        public bool CompleteOrder { get; set; }
    }
}
