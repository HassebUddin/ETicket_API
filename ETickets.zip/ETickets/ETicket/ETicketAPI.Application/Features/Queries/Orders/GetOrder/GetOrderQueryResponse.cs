﻿

namespace ETicketAPI.Application.Features.Queries.Orders.GetOrder
{
    public class GetOrderQueryResponse
    {
        public string Id { get; set; } = null!;
        public string OrderCode { get; set; } = null!;
        public DateTime CreateDate { get; set; }
        public float TotalPrice { get; set; }
        public string UserName { get; set; } = null!;
        public bool CompleteOrder { get; set; }
    }
}
