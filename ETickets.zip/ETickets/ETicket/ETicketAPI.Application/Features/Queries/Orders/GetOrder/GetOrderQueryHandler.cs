﻿

using ETicketAPI.Application.Dto;
using ETicketAPI.Application.IRepositories.Web.CompleteOrders;
using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace ETicketAPI.Application.Features.Queries.Orders.GetOrder
{
    public class GetOrderQueryHandler : IRequestHandler<GetOrderQueryRequest, List<GetOrderQueryResponse>>
    {
        private readonly IOrderReadRepository _orderReadRepository;
        private readonly ICompleteOrderReadRepository _completeOrderReadRepository;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public GetOrderQueryHandler(IOrderReadRepository orderReadRepository,
            IHttpContextAccessor httpContextAccessor,
            ICompleteOrderReadRepository completeOrderReadRepository)
        {
            _orderReadRepository = orderReadRepository;
            _httpContextAccessor = httpContextAccessor;
            _completeOrderReadRepository = completeOrderReadRepository;
        }

        public async Task<List<GetOrderQueryResponse>> Handle(GetOrderQueryRequest request, CancellationToken cancellationToken)
        {

            var pagiationParam = new PaginationParam { PageNumber = request.PageNumber, PageSize = request.PageSize };

            var pagedListOrders = _orderReadRepository.GetOrder(pagiationParam);
            var completeOrders = _completeOrderReadRepository.GetAll().ToList();


            var pagedListDto = new PagedListDto<Order>
            {
                CurrentPage = pagedListOrders.CurrentPage,
                TotalPages = pagedListOrders.TotalPages,
                PageSize = pagedListOrders.PageSize,
                TotalCount = pagedListOrders.TotalCount,
                Items = pagedListOrders.ToList()
            };

            _httpContextAccessor.HttpContext!.Session.SetString("paginationContent", JsonConvert.SerializeObject(pagedListDto, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            }));




            // Perform the right join operation in memory
            var result = pagedListOrders.ToList()
                .GroupJoin(
                    completeOrders,
                    o => o.Id,
                    c => c.OrderId,
                    (o, cs) => new
                    {
                        Order = o,
                        CompleteOrders = cs.DefaultIfEmpty()
                    })
                .SelectMany(
                    x => x.CompleteOrders.Select(c => new GetOrderQueryResponse()
                    {
                        CreateDate = x.Order.CreateDate,
                        UserName = x.Order.Basket.Users.UserName,
                        OrderCode = x.Order.OrderCode,
                        Id = x.Order.Id,
                        TotalPrice = x.Order.Basket.BasketItems.Sum(bi => bi.Products.Price * bi.Quantity),
                        CompleteOrder = c != null ?true:false// If there is a match, this will be true; otherwise false
                    })
                )
                .ToList();

            //var result= pagedListOrders.Select(x => new GetOrderQueryResponse()
            //  {


            //      CreateDate = x.CreateDate,
            //      UserName = x.Basket.Users.UserName,
            //      OrderCode = x.OrderCode,
            //      Id = x.Id,
            //      TotalPrice = x.Basket.BasketItems.Sum(bi => bi.Products.Price * bi.Quantity)

            //  }).ToList();
            return  result;

        }



     
    }
}
