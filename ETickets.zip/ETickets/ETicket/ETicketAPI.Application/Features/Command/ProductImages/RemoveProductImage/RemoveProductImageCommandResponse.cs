﻿

namespace ETicketAPI.Application.Features.Command.ProductImages.RemoveProductImage
{
    public class RemoveProductImageCommandResponse
    {
    }
}
