﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.ProductImages.RemoveProductImage
{
    public class RemoveProductImageCommandRequest:IRequest<RemoveProductImageCommandResponse>   
    {
        public string imageId { get; set; } = null!;
        public string productId { get; set; } = null!;

    }
}
