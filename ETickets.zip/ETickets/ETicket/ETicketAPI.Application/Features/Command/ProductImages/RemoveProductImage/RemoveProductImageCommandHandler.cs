﻿using ETicketAPI.Application.Abstractions.Storage;
using ETicketAPI.Application.IRepositories.Web.File.ProductFile;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Application.Features.Command.ProductImages.RemoveProductImage
{
    public class RemoveProductImageCommandHandler : IRequestHandler<RemoveProductImageCommandRequest, RemoveProductImageCommandResponse>
    {
        private readonly IProductReadRepository _productReadRepository;
        private readonly IProductWriteRepository _productWriteRepository;   

        private readonly IProductFileWriteRepository _productFileWriteRepository;   


        private readonly IStorageService _storageService;

        public RemoveProductImageCommandHandler(IProductReadRepository productReadRepository, IProductWriteRepository productWriteRepository,
         IStorageService storageService, IProductFileWriteRepository productFileWriteRepository)
        {
            _productReadRepository = productReadRepository;
            _productWriteRepository = productWriteRepository;
            _storageService = storageService;
            _productFileWriteRepository = productFileWriteRepository;
        }

        public async Task<RemoveProductImageCommandResponse> Handle(RemoveProductImageCommandRequest request, CancellationToken cancellationToken)
        {
            var product = await _productReadRepository.Table.Include(x => x.ProductFiles).FirstOrDefaultAsync(x => x.Id ==request.productId);
            if (product == null)
                throw new Exception(EntityMessage.EntityNotFound("Product"));

            var productFiles = product!.ProductFiles.FirstOrDefault(x => x.Id ==request.imageId);
            if (productFiles == null)
                throw new Exception(EntityMessage.EntityNotFound("Image"));

            //delete image into server
            _storageService.DeleteFile(productFiles!.Path, productFiles.FileName);

            //delete image in database
            _productFileWriteRepository.Remove(productFiles!);
            await _productWriteRepository.SaveChangeAsync();

            return new();
        }
    }
}
