﻿

using ETicketAPI.Application.IRepositories.Web.File.ProductFile;
using ETicketAPI.Application.IRepositories.Web.Products;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Application.Features.Command.ProductImages.ChangeShowCaseImage
{
    public class ChangeShowCaseImageHandler : IRequestHandler<ChangeShowCaseImageCommandRequest, ChangeShowCaseImageResponse>
    {
      private readonly IProductFileWriteRepository _productFileWriteRepository;

        public ChangeShowCaseImageHandler(IProductFileWriteRepository productFileWriteRepository)
        {
            _productFileWriteRepository = productFileWriteRepository;
        }

        public async Task<ChangeShowCaseImageResponse> Handle(ChangeShowCaseImageCommandRequest request, CancellationToken cancellationToken)
        {
            var query = _productFileWriteRepository.Table.Include(x => x.Products).SelectMany(x => x.Products, (pif, p) =>new
            {
                pif,p
    
            });

           var data= await query.FirstOrDefaultAsync(x => x.p.Id == request.productId && x.pif.ShowCase);
            if(data!=null)
              data.pif.ShowCase = false;

            var image= await query.FirstOrDefaultAsync(x => x.pif.Id == request.imageId);
            if(image!=null)
              image.pif.ShowCase = true;

          await  _productFileWriteRepository.SaveChangeAsync();

            return new();

        }
    }
}
