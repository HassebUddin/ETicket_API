﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.ProductImages.ChangeShowCaseImage
{

    public class ChangeShowCaseImageCommandRequest:IRequest<ChangeShowCaseImageResponse>
    {
        public string imageId { get; set; } = null!;
        public string productId { get; set; } = null!;
    }
}
