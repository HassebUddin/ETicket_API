﻿

namespace ETicketAPI.Application.Features.Command.ProductImages.ChangeShowCaseImage
{
    public class ChangeShowCaseImageResponse
    {

    }




}
