﻿
using MediatR;
using Microsoft.AspNetCore.Http;

namespace ETicketAPI.Application.Features.Command.ProductImages.UploadProductImage
{
    public class UploadProductImageCommandRequest:IRequest<UploadProductImageCommandResponse>
    {
        public IFormFileCollection IFormFile { get; set; } = null!;
        public string id { get; set; } = null!;
    }
}
