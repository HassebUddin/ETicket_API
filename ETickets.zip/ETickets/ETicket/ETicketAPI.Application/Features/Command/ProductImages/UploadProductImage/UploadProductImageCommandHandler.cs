﻿using ETicketAPI.Application.Abstractions.Storage;
using ETicketAPI.Application.IRepositories.Web.File.ProductFile;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Web;
using MediatR;

namespace ETicketAPI.Application.Features.Command.ProductImages.UploadProductImage
{
    public class UploadProductImageCommandHandler : IRequestHandler<UploadProductImageCommandRequest, UploadProductImageCommandResponse>
    {
        private readonly IProductReadRepository _productReadRepository;

        private readonly IProductFileWriteRepository _productFileWriteRepository;

        private readonly IStorageService _storageService;

        public UploadProductImageCommandHandler(IProductReadRepository productReadRepository, 
            IStorageService storageService, IProductFileWriteRepository productFileWriteRepository)
        {
            _productReadRepository = productReadRepository;
            _storageService = storageService;
            _productFileWriteRepository = productFileWriteRepository;
        }

        public async  Task<UploadProductImageCommandResponse> Handle(UploadProductImageCommandRequest request, CancellationToken cancellationToken)
        {
            

            string[] validExtension = { ".jpg", ".png", ".jpeg", ".json" };
            var product = await _productReadRepository.GetSingleAsync(x => x.Id == request.id);
            if (product == null)
                throw new Exception(EntityMessage.EntityNotFound("Product"));

            //store file in server
            var datas = await _storageService.UplaodFileAsync("resource\\product-image", validExtension, request.IFormFile);

            // Store file into database
            var productFiles = datas.Select(x => new ProductFiles
            {

                Id = Guid.NewGuid().ToString(),
                FileName = x.fileName,
                Path = x.path,
                Storage = _storageService.StorageName,
                Products = new List<Product>() { product }

            }).ToList();

            await _productFileWriteRepository.AddRangeAsync(productFiles);
            await _productFileWriteRepository.SaveChangeAsync();

            return new();
        }
    }
}
