﻿

namespace ETicketAPI.Application.Features.Command.ProductImages.UploadProductImage
{
    public class UploadProductImageCommandResponse
    {
    }
}
