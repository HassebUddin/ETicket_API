﻿

using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.IRepositories.Web.EndPoints;
using MediatR;

namespace ETicketAPI.Application.Features.Command.AuthorizationEndPoint
{
    public class AuthorizationEndPointCommandHandler : IRequestHandler<AuthorizationEndPointCommandRequest, AuthorizationEndPointCommandResponse>
    {
       private readonly IAuthorizationEndPointService _authorizationEndPointService;

        public AuthorizationEndPointCommandHandler(IAuthorizationEndPointService authorizationEndPointService)
        {
            _authorizationEndPointService = authorizationEndPointService;
        }

        public async Task<AuthorizationEndPointCommandResponse> Handle(AuthorizationEndPointCommandRequest request, CancellationToken cancellationToken)
        {

           await _authorizationEndPointService.AssignRoleEndPointAsync(request.Roles,request.Menu, request.Code, request.Type);
            return new();
        }
    }
}
