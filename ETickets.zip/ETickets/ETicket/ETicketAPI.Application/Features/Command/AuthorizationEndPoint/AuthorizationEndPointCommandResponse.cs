﻿
namespace ETicketAPI.Application.Features.Command.AuthorizationEndPoint
{
    public class AuthorizationEndPointCommandResponse
    {
    }
}
