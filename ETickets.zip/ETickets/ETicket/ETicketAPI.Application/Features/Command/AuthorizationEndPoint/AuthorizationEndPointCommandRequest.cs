﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.AuthorizationEndPoint
{
    public class AuthorizationEndPointCommandRequest:IRequest<AuthorizationEndPointCommandResponse>
    {
        public Type? Type { get; set; }
        public string[] Roles { get; set; } = null!;
        public string Menu { get; set; } = null!;
        public string Code { get; set; } = null!;
    }
}
