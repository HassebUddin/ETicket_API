﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.Accounts.Login
{
    public class LoginCommandRequest:IRequest<LoginCommandResponse>
    {
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;

    }
}
