﻿

namespace ETicketAPI.Application.Features.Command.Accounts.Login
{
    public class LoginCommandResponse
    {
    }
}
