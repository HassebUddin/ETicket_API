﻿

using AutoMapper;
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.ViewModel.Account;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Accounts.Login
{
    public class LoginCommandHandler : IRequestHandler<LoginCommandRequest, LoginCommandResponse>
    {
        private readonly IAccountService _accountService;

        private readonly IMapper _mapper;

        public LoginCommandHandler(IAccountService accountService, IMapper mapper)
        {
            _accountService = accountService;
            _mapper = mapper;
        }

        public async Task<LoginCommandResponse> Handle(LoginCommandRequest request, CancellationToken cancellationToken)
        {
            await _accountService.LoginAsync(_mapper.Map<LoginViewModel>(request));
            return new();
           
        }
    }
}
