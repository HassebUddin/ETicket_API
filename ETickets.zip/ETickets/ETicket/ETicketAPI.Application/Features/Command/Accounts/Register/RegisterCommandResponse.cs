﻿
namespace ETicketAPI.Application.Features.Command.Accounts.Register
{
    public class RegisterCommandResponse
    {
    }
}
