﻿

using AutoMapper;
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.ViewModel.Account;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Accounts.Register
{
    public class RegisterCommandHandler : IRequestHandler<RegisterCommandRequest, RegisterCommandResponse>
    {
        private readonly IAccountService  _accountService;

        private readonly IMapper _mapper;

        public RegisterCommandHandler(IAccountService accountService, IMapper mapper)
        {
            _accountService = accountService;
            _mapper = mapper;
        }

        public async Task<RegisterCommandResponse> Handle(RegisterCommandRequest request, CancellationToken cancellationToken)
        {
          await  _accountService.RegisterAsync(_mapper.Map<RegisterViewModel>(request));
            return new();
        }
    }
}
