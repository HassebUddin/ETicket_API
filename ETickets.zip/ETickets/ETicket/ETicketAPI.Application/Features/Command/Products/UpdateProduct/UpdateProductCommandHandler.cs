﻿

using AutoMapper;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using ETicketAPI.Domain.Entities.Web;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Products.UpdateProduct
{
    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommandRequest, UpdateProductCommandResponse>
    {
        private readonly IProductWriteRepository _productWriteRepository;
        private readonly IProductReadRepository _productReadRepository;

        private readonly IMapper _mapper;
        public UpdateProductCommandHandler(IProductWriteRepository productWriteRepository, IProductReadRepository productReadRepository, IMapper mapper)
        {
            _productWriteRepository = productWriteRepository;
            _productReadRepository = productReadRepository;
            _mapper = mapper;
        }

        public async Task<UpdateProductCommandResponse> Handle(UpdateProductCommandRequest request, CancellationToken cancellationToken)
        {
            var product = await _productReadRepository.GetByIdAsync(request.id);
            if (product == null) throw new Exception(EntityMessage.EntityNotFound("Id"));

            _productWriteRepository.Update(_mapper.Map(request, product));
            await _productWriteRepository.SaveChangeAsync();

            return new();
        }
    }
}
