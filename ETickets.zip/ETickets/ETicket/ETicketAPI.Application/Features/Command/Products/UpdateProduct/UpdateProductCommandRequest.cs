﻿

using MediatR;
using System.ComponentModel.DataAnnotations.Schema;

namespace ETicketAPI.Application.Features.Command.Products.UpdateProduct
{
    public class UpdateProductCommandRequest:IRequest<UpdateProductCommandResponse> 
    {
        public string id { get; set; } = null!;
        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }
    }
}
