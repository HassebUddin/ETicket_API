﻿
namespace ETicketAPI.Application.Features.Command.Products.UpdateProduct
{
    public class UpdateProductCommandResponse
    {
    }
}
