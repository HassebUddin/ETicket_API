﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.Products.CreateProduct
{
    public class CreateProductCommandRequest:IRequest<CreateProductCommandResponse> 
    {
        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }
    }
}
