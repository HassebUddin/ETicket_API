﻿
namespace ETicketAPI.Application.Features.Command.Products.CreateProduct
{
    public class CreateProductCommandResponse
    {
    }
}
