﻿

using AutoMapper;
using ETicketAPI.Application.Abstractions.Hubs;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Domain.Entities.Web;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Products.CreateProduct
{
    public class CreateProductCommandHandler : IRequestHandler<CreateProductCommandRequest, CreateProductCommandResponse>
    {
        private readonly IProductWriteRepository _productWriteRepository;

        private readonly IProductHubService _productHubService;

        private readonly IMapper _mapper;

        public CreateProductCommandHandler(IProductWriteRepository productWriteRepository, IMapper mapper, IProductHubService productHubService)
        {
            _productWriteRepository = productWriteRepository;
            _mapper = mapper;
            _productHubService = productHubService;
        }

        public async Task<CreateProductCommandResponse> Handle(CreateProductCommandRequest request, CancellationToken cancellationToken)
        {
            var product = _mapper.Map<Product>(request);

            await _productWriteRepository.AddAsync(product);
            await _productWriteRepository.SaveChangeAsync();

           await _productHubService.ProdcutAddMessage($"{request.Name} is add successfully ");
            return new();

        }
    }
}
