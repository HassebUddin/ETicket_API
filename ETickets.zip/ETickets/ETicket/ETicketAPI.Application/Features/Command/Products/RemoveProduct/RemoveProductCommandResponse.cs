﻿

namespace ETicketAPI.Application.Features.Command.Products.RemoveProduct
{
    public class RemoveProductCommandResponse
    {
    }
}
