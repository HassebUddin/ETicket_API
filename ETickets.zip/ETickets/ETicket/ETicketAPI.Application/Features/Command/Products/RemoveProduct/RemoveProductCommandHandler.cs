﻿

using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.Messages;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Products.RemoveProduct
{
    public class RemoveProductCommandHandler : IRequestHandler<RemoveProductCommandRequest, RemoveProductCommandResponse>
    {
        private readonly IProductReadRepository _productReadRepository;
        private readonly IProductWriteRepository _productWriteRepository;

        public RemoveProductCommandHandler(IProductReadRepository productReadRepository, IProductWriteRepository productWriteRepository)
        {
            _productReadRepository = productReadRepository;
            _productWriteRepository = productWriteRepository;
        }

        public async Task<RemoveProductCommandResponse> Handle(RemoveProductCommandRequest request, CancellationToken cancellationToken)
        {
            var product = await _productReadRepository.GetByIdAsync(request.id);
            if (product == null)  throw new Exception(EntityMessage.EntityNotFound("Id"));

            _productWriteRepository.Remove(product);
            await _productWriteRepository.SaveChangeAsync();
            
            return new();

        }
    }
}
