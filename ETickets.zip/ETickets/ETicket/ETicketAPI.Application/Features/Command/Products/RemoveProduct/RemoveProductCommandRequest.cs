﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.Products.RemoveProduct
{
    public class RemoveProductCommandRequest:IRequest<RemoveProductCommandResponse> 
    {
        public string id { get; set; } = null!;
    }
}
