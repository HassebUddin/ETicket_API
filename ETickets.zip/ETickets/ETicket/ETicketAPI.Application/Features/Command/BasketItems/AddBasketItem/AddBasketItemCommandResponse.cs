﻿

namespace ETicketAPI.Application.Features.Command.BasketItems.AddBasketItem
{
    public class AddBasketItemCommandResponse
    {
    }
}
