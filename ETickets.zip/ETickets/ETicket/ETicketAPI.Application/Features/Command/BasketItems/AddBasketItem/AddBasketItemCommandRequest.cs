﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.BasketItems.AddBasketItem
{
    public class AddBasketItemCommandRequest:IRequest<AddBasketItemCommandResponse>
    {
        public string productId { get; set; } = null!;
        public int quantity { get; set; }

    }
}
