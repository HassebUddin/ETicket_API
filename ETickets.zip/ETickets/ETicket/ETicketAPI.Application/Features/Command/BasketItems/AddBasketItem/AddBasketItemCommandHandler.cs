﻿

using ETicketAPI.Application.Abstractions.Service;
using MediatR;

namespace ETicketAPI.Application.Features.Command.BasketItems.AddBasketItem
{
    public class AddBasketItemCommandHandler : IRequestHandler<AddBasketItemCommandRequest, AddBasketItemCommandResponse>
    {
        private readonly IBasketService _basketService;

        public AddBasketItemCommandHandler(IBasketService basketService)
        {
            _basketService = basketService;
        }

        public async Task<AddBasketItemCommandResponse> Handle(AddBasketItemCommandRequest request, CancellationToken cancellationToken)
        {
    await   _basketService.AddItemToBasketAsync(new()
            {
                ProductId = request.productId,
                Quantity = request.quantity,
            });

            return new();
        }
    }
}
