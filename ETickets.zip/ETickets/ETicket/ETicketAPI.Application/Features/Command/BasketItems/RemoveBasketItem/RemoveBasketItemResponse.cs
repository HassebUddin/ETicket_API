﻿
namespace ETicketAPI.Application.Features.Command.BasketItems.RemoveBasketItem
{
    public class RemoveBasketItemResponse
    {
    }
}
