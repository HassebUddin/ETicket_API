﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.BasketItems.RemoveBasketItem
{
    public class RemoveBasketItemRequest:IRequest<RemoveBasketItemResponse>
    {
        public string BasketItemId { get; set; } = null!;
    }
}
