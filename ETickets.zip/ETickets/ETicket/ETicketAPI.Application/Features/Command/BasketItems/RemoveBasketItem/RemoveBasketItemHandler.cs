﻿
using ETicketAPI.Application.Abstractions.Service;
using MediatR;

namespace ETicketAPI.Application.Features.Command.BasketItems.RemoveBasketItem
{
    public class RemoveBasketItemHandler : IRequestHandler<RemoveBasketItemRequest, RemoveBasketItemResponse>
    {
        private readonly IBasketService  _basketService;

        public RemoveBasketItemHandler(IBasketService basketService)
        {
            _basketService = basketService;
        }

        public async Task<RemoveBasketItemResponse> Handle(RemoveBasketItemRequest request, CancellationToken cancellationToken)
        {

            await _basketService.RemoveBasketItemAsync(request.BasketItemId);
            return new();
        }
    }
}
