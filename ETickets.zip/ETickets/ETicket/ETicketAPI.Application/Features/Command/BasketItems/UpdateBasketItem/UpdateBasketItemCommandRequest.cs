﻿using MediatR;


namespace ETicketAPI.Application.Features.Command.BasketItems.UpdateBasketItem
{
    public class UpdateBasketItemCommandRequest : IRequest<UpdateBasketItemCommandResponse>
    {
        public string BasketId { get; set; } = null!;
        public int quantity { get; set; }
        public string ProductName { get; set; } = null!;
    }
}
