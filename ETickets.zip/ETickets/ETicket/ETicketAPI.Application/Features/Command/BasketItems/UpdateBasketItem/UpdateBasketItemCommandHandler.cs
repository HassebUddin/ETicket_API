﻿using ETicketAPI.Application.Abstractions.Service;
using MediatR;

namespace ETicketAPI.Application.Features.Command.BasketItems.UpdateBasketItem
{
    public class UpdateBasketItemCommandHandler : IRequestHandler<UpdateBasketItemCommandRequest, UpdateBasketItemCommandResponse>
    {
        private readonly IBasketService _basketService;

        public UpdateBasketItemCommandHandler(IBasketService basketService)
        {
            _basketService = basketService;
        }

        public async Task<UpdateBasketItemCommandResponse> Handle(UpdateBasketItemCommandRequest request, CancellationToken cancellationToken)
        {
            await _basketService.UpateBasketItemAsync(new()
            {
                BasketId = request.BasketId,
                Quantity = request.quantity,
                ProductName=request.ProductName
            });
            return new();
        }
    }
}
