﻿namespace ETicketAPI.Application.Features.Command.BasketItems.UpdateBasketItem
{
    public class UpdateBasketItemCommandResponse
    {
    }
}
