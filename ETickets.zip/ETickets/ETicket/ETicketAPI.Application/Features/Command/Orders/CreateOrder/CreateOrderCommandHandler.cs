﻿using ETicketAPI.Application.Abstractions.Hubs;
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.IRepositories.Web.Orders;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Application.Features.Command.Orders.CreateOrder
{
    public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommandRequest, CreateOrderCommandResponse>
    {
      


        private readonly IOrderWriteRepository _orderWriteRepository;
        private readonly IOrderReadRepository _orderReadRepository;

        private readonly IBasketService _basketService;
        private readonly IOrderHubService _orderHubService;

        public CreateOrderCommandHandler(IOrderWriteRepository orderWriteRepository, IOrderReadRepository orderReadRepository,
            IBasketService basketService, IOrderHubService orderHubService)
        {
            _orderWriteRepository = orderWriteRepository;
            _orderReadRepository = orderReadRepository;
            _basketService = basketService;
            _orderHubService = orderHubService;
        }

        public async Task<CreateOrderCommandResponse> Handle(CreateOrderCommandRequest request, CancellationToken cancellationToken)
        {
            var orderCode = (new Random().NextDouble()*10000).ToString();
            orderCode =   orderCode.Substring(orderCode.IndexOf('.')+1 , orderCode.Length - orderCode.IndexOf('.') - 1);
          
            await _orderWriteRepository.AddAsync(new()
            {
                OrderCode = orderCode,
                Address = request.Address,
                Description = request.Description,
                Id = _basketService.GetActiveUserBasket.Id
            });

            await _orderWriteRepository.SaveChangeAsync();
            _orderHubService.OrderAddMessage("User order place succeessfully");
            return new();
        }
    }
}
