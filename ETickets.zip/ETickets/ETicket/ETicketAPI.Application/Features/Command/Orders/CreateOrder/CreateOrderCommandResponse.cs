﻿namespace ETicketAPI.Application.Features.Command.Orders.CreateOrder
{
    public class CreateOrderCommandResponse
    {
    }
}
