﻿using MediatR;

namespace ETicketAPI.Application.Features.Command.Orders.CreateOrder
{
    public class CreateOrderCommandRequest:IRequest<CreateOrderCommandResponse>
    {
        public string Description { get; set; } = null!;
        public string Address { get; set; } = null!;
    }
}
