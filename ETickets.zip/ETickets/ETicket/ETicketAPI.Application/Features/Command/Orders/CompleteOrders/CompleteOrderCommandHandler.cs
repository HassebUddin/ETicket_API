﻿
using ETicketAPI.Application.IRepositories.Web.CompleteOrders;
using MediatR;
using Microsoft.AspNetCore.Components.Forms;

namespace ETicketAPI.Application.Features.Command.Orders.CompleteOrders
{
    public class CompleteOrderCommandHandler : IRequestHandler<CompleteOrderCommandRequest, CompleteOrderCommandResponse>
    {
        private readonly ICompleteOrderWriteRepository _completeOrderWriteRepository;

        public CompleteOrderCommandHandler(ICompleteOrderWriteRepository completeOrderWriteRepository)
        {
            _completeOrderWriteRepository = completeOrderWriteRepository;
        }

        public async Task<CompleteOrderCommandResponse> Handle(CompleteOrderCommandRequest request, CancellationToken cancellationToken)
        {
      
            await  _completeOrderWriteRepository.AddAsync(new() { OrderId=request.OrderId, });
            await _completeOrderWriteRepository.SaveChangeAsync();
            return new();
        }
    }
}
