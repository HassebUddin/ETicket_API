﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.Orders.CompleteOrders
{
    public class CompleteOrderCommandRequest:IRequest<CompleteOrderCommandResponse>
    {
        public string OrderId { get; set; } = null!;
    }
}
