﻿

namespace ETicketAPI.Application.Features.Command.Orders.CompleteOrders
{
    public class CompleteOrderCommandResponse
    {
    }
}
