﻿
using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Application.Messages;
using MediatR;

namespace ETicketAPI.Application.Features.Command.Orders.RemoveOrder
{
    public class RemoveOrderCommandHandler : IRequestHandler<RemoveOrderCommandRequest, RemoveOrderCommandResponse>
    {
        private readonly IOrderWriteRepository _orderWriteRepository;
        private readonly IOrderReadRepository _orderReadRepository;

        public RemoveOrderCommandHandler(IOrderWriteRepository orderWriteRepository, IOrderReadRepository orderReadRepository)
        {
            _orderWriteRepository = orderWriteRepository;
            _orderReadRepository = orderReadRepository;
        }

        public async Task<RemoveOrderCommandResponse> Handle(RemoveOrderCommandRequest request, CancellationToken cancellationToken)
        {
           var getOrder= await _orderReadRepository.GetByIdAsync(request.OrderId);
            if(getOrder == null)
                throw new Exception(EntityMessage.EntityNotFound("Order"));

         _orderWriteRepository.Remove(getOrder);
         await _orderWriteRepository.SaveChangeAsync();
            return new();

        }
    }
}
