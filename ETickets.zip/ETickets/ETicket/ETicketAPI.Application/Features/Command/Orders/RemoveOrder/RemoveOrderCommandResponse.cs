﻿
namespace ETicketAPI.Application.Features.Command.Orders.RemoveOrder
{
    public  class RemoveOrderCommandResponse
    {
    }
}
