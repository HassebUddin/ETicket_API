﻿

using MediatR;

namespace ETicketAPI.Application.Features.Command.Orders.RemoveOrder
{
    public  class RemoveOrderCommandRequest:IRequest<RemoveOrderCommandResponse>    
    {
        public string OrderId { get; set; } = null!;
    }
}
