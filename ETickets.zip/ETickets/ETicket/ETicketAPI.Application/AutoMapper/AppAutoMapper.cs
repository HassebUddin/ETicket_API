﻿

using AutoMapper;
using ETicketAPI.Application.Features.Command.Accounts.Login;
using ETicketAPI.Application.Features.Command.Accounts.Register;
using ETicketAPI.Application.Features.Command.Products.CreateProduct;
using ETicketAPI.Application.Features.Command.Products.UpdateProduct;
using ETicketAPI.Application.Features.Queries.ProductImages.GetProductImage;
using ETicketAPI.Application.Features.Queries.Products.GeProductById;
using ETicketAPI.Application.Features.Queries.Products.GetProduct;
using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Application.ViewModel.Account;
using ETicketAPI.Application.ViewModel.Identity.Role;
using ETicketAPI.Application.ViewModel.Identity.User;
using ETicketAPI.Application.ViewModel.Web.Product;
using ETicketAPI.Domain.Entities.Identity;
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.AutoMapper
{
    public class AppAutoMapper : Profile
    {
        public AppAutoMapper()
        {
            //Product AutoMapper
            CreateMap<CreateProductCommandRequest, Product>().ReverseMap();
            CreateMap<UpdateProductCommandRequest, Product>().ReverseMap();
            CreateMap<GeProductByIdQueryResponse, Product>().ReverseMap();

            //account AutoMapper
            CreateMap<RegisterViewModel, AppUser>().ForMember(des=>des.UserName,x=>x.MapFrom(src=>src.Email)).ReverseMap();
            CreateMap<RegisterCommandRequest, RegisterViewModel>().ReverseMap();

            CreateMap<LoginViewModel, AppUser>().ReverseMap();
            CreateMap<LoginCommandRequest, LoginViewModel>().ReverseMap();



            //productFile
            CreateMap<GetProductImageQueryResponse, ProductFiles>().ReverseMap();


            //Role AutoMapper
            CreateMap<RoleCreateViewModel, AppRole>().ReverseMap();
            CreateMap<RoleUpdateViewModel, AppRole>().ReverseMap();
            CreateMap<RoleListViewModel, AppRole>().ReverseMap();


            //User AutoMapper
            CreateMap<UserCreateViewModel,AppUser>().ReverseMap();
            CreateMap<UserUpdateViewModel, AppUser>().ReverseMap();
            CreateMap<UserListViewModel, AppUser>().ReverseMap();



        }
    }
}
