﻿
using Microsoft.AspNetCore.Routing;

namespace ETicketAPI.Application.Messages
{
    public static class ApiResponseMessage
    {
        public static object SuccessResponse(string HttpMethodName)
        => new {  message = $"entity {HttpMethodName} successfully" };

        public static object CustomResponse(string messages)
      => new { message = messages };

        public static object NotFoundResponse(string columnName)
        =>  new {  message = $"{columnName} does not exist" };
           
        

        public static object BadResponse()
        =>  new {  message = $"something went wrong please try again!" };
          
        

        public static object BadResponse(string message)
        => new {  message = $"{message}" };

        

    }
}
