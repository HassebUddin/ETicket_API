﻿
namespace ETicketAPI.Application.Messages
{
    public  static class FluentMessages
    {
        public static string NotNullMessage(string propertyName) => $"{propertyName} is required";
        public static string EmailMessage(string propertyName) => $"{propertyName} is not corect format";
        public static string InValidIntigerMessage(string propertyName)=> $"{propertyName} is not valid";
        
    }
}
