﻿

namespace ETicketAPI.Application.Messages
{
    public static class EntityMessage
    {
        public static string EntityAlreadyExist(string Name)
        =>   $"{Name} already exists";

        public static string EntityNotFound(string Name)
       => $"{Name} is notfound";

        public static object EntityDeleted(string Name)
       => new { message = $"{Name} is Deleted Successfully" };
           

    }
}
