﻿using ETicketAPI.Application.Messages;
using ETicketAPI.Application.ViewModel.Identity.User;
using FluentValidation;

namespace ETicketAPI.Application.FluentValidation.Identity.User
{
    public class UserAddValidator : AbstractValidator<UserCreateViewModel>
    {
        public UserAddValidator()
        {
            RuleFor(x => x.Address).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.Email).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.Password).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.City).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.Country).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.Profession).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.FullName).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));
            RuleFor(x => x.gender).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Address"));

            RuleFor(x => x.Email).EmailAddress().WithMessage(FluentMessages.EmailMessage("Email"));
        }
    }
}
