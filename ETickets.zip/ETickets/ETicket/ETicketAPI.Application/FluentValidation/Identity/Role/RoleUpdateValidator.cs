﻿
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.ViewModel.Identity.Role;
using FluentValidation;

namespace ETicketAPI.Application.FluentValidation.Identity.Role
{
    public class RoleUpdateValidator : AbstractValidator<RoleUpdateViewModel>
    {
        public RoleUpdateValidator()
        =>  RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Name"));

        
    }
}
