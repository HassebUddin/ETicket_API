﻿
using ETicketAPI.Application.Messages;
using ETicketAPI.Application.ViewModel.Web.Product;
using FluentValidation;

namespace ETicketAPI.Application.FluentValidation.Web.Product
{
    public class UpdateProductValidator : AbstractValidator<UpdateProductViewModel>
    {
        public UpdateProductValidator()
        {
            RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Name"));

            RuleFor(x => x.Price).NotEmpty().NotNull().WithMessage(FluentMessages.InValidIntigerMessage("Price"));



            RuleFor(x => x.Stock).NotEmpty().NotNull().WithMessage(FluentMessages.InValidIntigerMessage("Stock"));
           
        }
    }
}
