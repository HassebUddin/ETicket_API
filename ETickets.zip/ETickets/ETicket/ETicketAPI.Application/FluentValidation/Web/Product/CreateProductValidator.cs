﻿

using ETicketAPI.Application.Messages;
using ETicketAPI.Application.ViewModel.Web.Product;
using FluentValidation;

namespace ETicketAPI.Application.FluentValidation.Web.Product
{
    public class CreateProductValidator : AbstractValidator<CreateProductViewModel>
    {
        public CreateProductValidator()
        {
            RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage(FluentMessages.NotNullMessage("Name"));
          
            RuleFor(x => x.Price)
 .Cascade(CascadeMode.Stop) // Stop validating if the first rule fails
            .Must(s=>s>=0).WithMessage(FluentMessages.InValidIntigerMessage("Price"));
            
            RuleFor(x => x.Stock)
            .Must(s => s >=0).WithMessage(FluentMessages.InValidIntigerMessage("Stock"));
            

        }
    }
}
