﻿

namespace ETicketAPI.Application.Consts
{
    public static class AuthorizationDefinitionConstant
    {
        public const string Basket = "Basket";
        public const string Order = "Order";
        public const string Product = "Product";
        public const string Role = "Role";
        public const string User = "User";
    }
}
