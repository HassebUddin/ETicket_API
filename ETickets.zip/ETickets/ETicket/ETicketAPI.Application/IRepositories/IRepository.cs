﻿
using ETicketAPI.Domain.Entities.Common;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Application.IRepositories
{
    public  interface IRepository<T> where T : BaseEntity
    {
        public DbSet<T> Table { get; } 

    }
}
