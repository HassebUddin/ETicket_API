﻿

using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Identity;

namespace ETicketAPI.Application.IRepositories.Identity.User
{
    public interface IUserReadRepository
    {
        PagedList<AppUser> GetUsers(PaginationParam param);
        Task<AppUser> GetUserByIdAsync(string id);
    }
}
