﻿

using ETicketAPI.Domain.Entities.Identity;

namespace ETicketAPI.Application.IRepositories.Identity.User
{
    public interface IUserWriteRepository
    {
        Task AddUserAsync(AppUser request);
        Task UpdateUserAsync(AppUser request);
        Task DeleteUserAsync(string id);
    }
}
