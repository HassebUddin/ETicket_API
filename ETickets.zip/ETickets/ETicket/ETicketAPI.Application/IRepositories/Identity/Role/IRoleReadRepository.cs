﻿

using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Identity;

namespace ETicketAPI.Application.IRepositories.Identity.Role
{
    public interface IRoleReadRepository
    {
        PagedList<AppRole> GetRoles(PaginationParam param);
        Task<AppRole> GetRoleByIdAsync(string id);
    }
}
