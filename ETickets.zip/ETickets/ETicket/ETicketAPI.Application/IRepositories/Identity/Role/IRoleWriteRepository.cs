﻿
using ETicketAPI.Domain.Entities.Identity;

namespace ETicketAPI.Application.IRepositories.Identity.Role
{
    public interface IRoleWriteRepository
    {
        Task AddRoleAsync(AppRole request);
        Task UpdateRoleAsync(AppRole request);
        Task DeleteRoleAsync(string id);
    }
}
