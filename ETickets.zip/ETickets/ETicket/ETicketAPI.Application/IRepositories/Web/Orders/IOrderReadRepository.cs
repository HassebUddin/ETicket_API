﻿using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.Orders
{
    public interface IOrderReadRepository : IReadRepository<Order>
    {
        PagedList<Order> GetOrder(PaginationParam param, bool AsNoTracking = true);
    }
}
