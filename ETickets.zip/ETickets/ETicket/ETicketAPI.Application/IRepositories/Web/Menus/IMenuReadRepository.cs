﻿
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.Menus
{
    public interface IMenuReadRepository:IReadRepository<Menu>
    {
    }
}
