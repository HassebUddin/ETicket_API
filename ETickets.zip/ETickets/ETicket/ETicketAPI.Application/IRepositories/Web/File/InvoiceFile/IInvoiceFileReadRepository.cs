﻿
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.File.InvoiceFile
{
    public interface IInvoiceFileReadRepository:IReadRepository<InvoiceFiles>
    {
    }
}
