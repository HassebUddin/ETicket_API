﻿

using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.File.InvoiceFile
{
    public interface IInvoiceFileWriteRepository:IWriteRepository<InvoiceFiles>
    {
    }
}
