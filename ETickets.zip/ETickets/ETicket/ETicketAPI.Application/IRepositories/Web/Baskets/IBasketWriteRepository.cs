﻿
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.Baskets
{
    public interface IBasketWriteRepository:IWriteRepository<Basket>
    {
    }
}
