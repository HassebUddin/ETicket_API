﻿using ETicketAPI.Domain.Entities;

namespace ETicketAPI.Application.IRepositories.Web.Customers
{
    public interface ICustomerReadRepository : IReadRepository<Customer>
    {
    }
}
