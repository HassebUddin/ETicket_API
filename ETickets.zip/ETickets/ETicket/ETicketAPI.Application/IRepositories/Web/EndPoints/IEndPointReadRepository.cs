﻿


using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.EndPoints
{
    public interface IEndPointReadRepository:IReadRepository<EntityEndPoint>
    {
    }
}
