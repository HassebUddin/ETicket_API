﻿

using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.CompleteOrders
{
    public interface ICompleteOrderReadRepository:IReadRepository<CompleteOrder>
    {
    }
}
