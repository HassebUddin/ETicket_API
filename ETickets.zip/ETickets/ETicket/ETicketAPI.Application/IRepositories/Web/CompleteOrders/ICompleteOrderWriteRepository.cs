﻿
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.CompleteOrders
{
    public interface ICompleteOrderWriteRepository:IWriteRepository<CompleteOrder>
    {
    }
}
