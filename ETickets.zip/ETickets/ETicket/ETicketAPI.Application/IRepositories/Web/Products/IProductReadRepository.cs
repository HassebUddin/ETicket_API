﻿using ETicketAPI.Application.RequestParamters;
using ETicketAPI.Domain.Entities.Web;

namespace ETicketAPI.Application.IRepositories.Web.Products
{
    public interface IProductReadRepository : IReadRepository<Product>
    {
        PagedList<Product> GetProduct(PaginationParam param,bool AsNoTracking=true);   
    }
}
