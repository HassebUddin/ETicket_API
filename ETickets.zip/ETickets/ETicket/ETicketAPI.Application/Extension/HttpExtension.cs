﻿

using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace ETicketAPI.Application.Extension
{
    public static class HttpExtension
    {
        public static void AddPaginationHeader(this HttpResponse response,int CurrentPage,int totalPages
            ,int pageSize,int totalCount)
        {
            var pagination=new PaginationHeader(CurrentPage, totalPages, pageSize, totalCount);
            response.Headers.Add("Pagination", JsonSerializer.Serialize(pagination));
            response.Headers.Add("Access-Control-Expose-Headers", "Pagination");
        }
    }



    public class PaginationHeader
    {
        public PaginationHeader(int currentPage, int totalPages, int pageSize, int totalCount)
        {
            CurrentPage = currentPage;
            TotalPages = totalPages;
            PageSize = pageSize;
            TotalCount = totalCount;
        }

        public int CurrentPage { get; private set; }
        public int TotalPages { get; private set; }
        public int PageSize { get; private set; }
        public int TotalCount { get; private set; }
    }
}
