﻿

namespace ETicketAPI.Application.Enums
{
    public enum ActionType
    {
        Writting,
        Reading 
       ,Updating,
        Deleting
    }
}
