﻿
using ETicketAPI.Application.Abstractions.Service;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace ETicketAPI.Application
{
    public static class ServiceRegisteration
    {
        public static IServiceCollection AddApplicationService(this IServiceCollection services)
        {
            //inject MediatR
            services.AddMediatR(typeof(ServiceRegisteration));




            return services;
        }

    }
}
