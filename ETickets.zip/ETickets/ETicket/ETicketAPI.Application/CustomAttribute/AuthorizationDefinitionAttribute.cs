﻿
using ETicketAPI.Application.Enums;

namespace ETicketAPI.Application.CustomAttribute
{
    public class AuthorizationDefinitionAttribute:Attribute
    {

        public string Menu { get; set; } = null!;
        public string Definition { get; set; } = null!;
        public ActionType ActionType { get; set; } 
       

    }
}
