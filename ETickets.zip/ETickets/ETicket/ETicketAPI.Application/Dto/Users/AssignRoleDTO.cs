﻿
namespace ETicketAPI.Application.Dto.Users
{
    public class AssignRoleDTO
    {
        public string[] Role { get; set; } = null!;
        public string UserId { get; set; } = null!;
    }
}
