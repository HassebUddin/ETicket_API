﻿namespace ETicketAPI.Application.Dto.Orders
{
    public class CreateOrder
    {
        public string Description { get; set; } = null!;
        public string Address { get; set; } = null!;


    }
}
