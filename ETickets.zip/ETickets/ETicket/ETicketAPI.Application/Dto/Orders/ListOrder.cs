﻿

namespace ETicketAPI.Application.Dto.Orders
{
    public class ListOrder
    {
        public string Id { get; set; } = null!;
        public string OrderCode { get; set; } = null!;
        public DateTime CreateDate { get; set; }
        public float TotalPrice { get; set; }
        public string UserName { get; set; } = null!;



    }
}
