﻿

namespace ETicketAPI.Application.Dto.Configurations
{
    public class Menu
    {
        public string Name { get; set; } = null!;
        public List<Action> Actions { get; set; } = new();
    }
}
