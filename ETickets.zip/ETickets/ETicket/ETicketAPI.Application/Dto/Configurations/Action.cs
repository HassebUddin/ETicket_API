﻿

using ETicketAPI.Application.Enums;

namespace ETicketAPI.Application.Dto.Configurations
{
    public class Action
    {
        public string Code { get; set; } = null!;
        public string ActionType { get; set; } = null!;
        public string HttpType { get; set; } = null!;
        public string Definition { get; set; } = null!;
    }
}
