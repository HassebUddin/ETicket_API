﻿

namespace ETicketAPI.Application.ViewModel.Identity.Role
{
    public class RoleCreateViewModel
    {
        public string Name { get; set; } = null!;
        public string Id { get; set; } =Guid.NewGuid().ToString();

    }
}
