﻿

namespace ETicketAPI.Application.ViewModel.Identity.Role
{
    public class RoleUpdateViewModel
    {

        public string Name { get; set; } = null!;
        public string Id { get; set; } = null!;
    }
}
