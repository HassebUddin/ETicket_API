﻿
namespace ETicketAPI.Application.ViewModel.Identity.User
{
    public class UserUpdateViewModel
    {
        public bool Status { get; set; } = true;
        public string Id { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Email { get; set; } = null!;

        public string FullName { get; set; } = null!;
        public string Profession { get; set; } = null!;
        public string gender { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string City { get; set; } = null!;
        public string Country { get; set; } = null!;
    }
}
