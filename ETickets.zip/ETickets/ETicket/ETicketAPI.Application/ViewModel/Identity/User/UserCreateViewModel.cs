﻿

namespace ETicketAPI.Application.ViewModel.Identity.User
{
    public class UserCreateViewModel
    {
        public string Id { get; set; } =Guid.NewGuid().ToString();
        public string Password { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string FullName { get; set; } = null!;
        public string Profession { get; set; } = null!;
        public string gender { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string City { get; set; } = null!;
        public string Country { get; set; } = null!;
    }
}
