﻿

namespace ETicketAPI.Application.ViewModel.Identity.User
{
    public class UserListViewModel
    {
        public bool Status { get; set; }
        public string Id { get; set; } = null!;
        public string Email { get; set; } = null!;

        public string FullName { get; set; } = null!;
        public string Profession { get; set; } = null!;
        public string gender { get; set; } = null!;
        public string City { get; set; } = null!;
        public string Country { get; set; } = null!;
    }
}
