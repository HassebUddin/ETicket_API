﻿
namespace ETicketAPI.Application.ViewModel.Web.Product
{
    public class UpdateProductViewModel
    {

        public string Name { get; set; } = null!;
        public int Stock { get; set; }
        public long Price { get; set; }
    }
}
