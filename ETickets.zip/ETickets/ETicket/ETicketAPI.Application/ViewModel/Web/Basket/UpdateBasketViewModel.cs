﻿
namespace ETicketAPI.Application.ViewModel.Web.Basket
{
    public class UpdateBasketViewModel
    {
        public string BasketId { get; set; } = null!;
        public int Quantity { get; set; }
        public string ProductName { get; set; } = null!;

    }
}
