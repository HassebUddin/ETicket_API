﻿
namespace ETicketAPI.Application.ViewModel.Web.Basket
{
    public class CreateBasketViewModel
    {

        public string ProductId { get; set; } = null!;
        public int Quantity { get; set; }
    }
}
