﻿

using ETicketAPI.Application.CustomAttribute;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Routing;
using System.Reflection;

namespace ETicketAPI.Infrastructure.Filters
{
    public class RolePermisionFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var user = "admin@gmail.com";
            if (user != null)
            {
               var descriptor= context.ActionDescriptor as ControllerActionDescriptor;

              var attribute=  descriptor!.MethodInfo.GetCustomAttribute(typeof(AuthorizationDefinitionAttribute)) as AuthorizationDefinitionAttribute;
              var httpAttribute = descriptor.MethodInfo.GetCustomAttribute(typeof(HttpMethodAttribute)) as HttpMethodAttribute;

              var code= $"{attribute!.ActionType},{(httpAttribute != null? httpAttribute.HttpMethods.First():HttpMethod.Get)}," +
                    $"{attribute.Definition}".Replace(" ", "");

                var hasrole = true;
                if (!hasrole)
                    context.Result = new UnauthorizedResult();
                else
                    await next();

            }
            else
             await next();
        }
    }
}
