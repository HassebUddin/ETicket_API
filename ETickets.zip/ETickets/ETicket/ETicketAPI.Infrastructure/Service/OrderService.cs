﻿

using ETicketAPI.Application.Abstractions.Hubs;
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.Dto.Orders;
using ETicketAPI.Application.IRepositories.Web.Orders;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Infrastructure.Service
{
    public class OrderService:IOrderService
    {
        private readonly IOrderWriteRepository _orderWriteRepository;
        private readonly IOrderReadRepository _orderReadRepository;

        private readonly IBasketService _basketService;
        private readonly IOrderHubService _orderHubService;

        public async Task CreateOrder(CreateOrder order)
        {
            var orderCode = new Random().NextDouble().ToString();
            orderCode.Substring(orderCode.IndexOf('.') + 1, orderCode.Length - orderCode.IndexOf('.') + 1);
            await  _orderWriteRepository.AddAsync(new()
            {
                OrderCode= orderCode,       
                Address = order.Address,
                Description = order.Description,
                Id = _basketService.GetActiveUserBasket.Id
            });

            await _orderWriteRepository.SaveChangeAsync();
            _orderHubService.OrderAddMessage("User order place succeessfully");

        }

        public Task<List<ListOrder>> GetOrders()
        {
            var query = _orderReadRepository.Table.Include(o => o.Basket).ThenInclude(b => b.Users)
                            .Include(u => u.Basket).ThenInclude(b => b.BasketItems)
                            .ThenInclude(bi => bi.Products).Select(x => new ListOrder()
                            {
                                CreateDate=x.CreateDate,
                                UserName=x.Basket.Users.UserName,
                                OrderCode=x.OrderCode,
                                Id=x.Id,
                                TotalPrice=x.Basket.BasketItems.Sum(bi=>bi.Products.Price*bi.Quantity)

                            });
            return null!;

        }
    }
}
