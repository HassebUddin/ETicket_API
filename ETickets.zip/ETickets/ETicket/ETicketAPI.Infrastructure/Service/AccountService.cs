﻿

using AutoMapper;
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.ViewModel.Account;
using ETicketAPI.Domain.Entities.Identity;
using Microsoft.AspNetCore.Identity;

namespace ETicketAPI.Infrastructure.Service
{
    public class AccountService : IAccountService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;

        private readonly IMapper _mapper;

        public AccountService(UserManager<AppUser> userManager, IMapper mapper, SignInManager<AppUser> signInManager)
        {
            _userManager = userManager;
            _mapper = mapper;
            _signInManager = signInManager;
        }

        public async Task LoginAsync(LoginViewModel login)
        {
        var user=   await _userManager.FindByEmailAsync(login.Email);
           if(user==null)
                throw new Exception("Email is already exist");

            var checkPassowrd = await _userManager.CheckPasswordAsync(user, login.Password);
            if(!checkPassowrd)
                throw new Exception("password is in not valid");

            await _signInManager.PasswordSignInAsync(user, login.Password, false, false);
            
        }

        public async Task RegisterAsync(RegisterViewModel register)
        {

            var result=  await _userManager.CreateAsync(_mapper.Map<AppUser>(register),register.Password);
            if (result.Succeeded)
            {
                var getEmail =await _userManager.FindByEmailAsync(register.Email);
                await _userManager.AddToRoleAsync(getEmail, "User");
            }
            else
             throw new Exception(result.Errors.Select(x => x.Description).FirstOrDefault()!);
              
        
        }
    }
}
