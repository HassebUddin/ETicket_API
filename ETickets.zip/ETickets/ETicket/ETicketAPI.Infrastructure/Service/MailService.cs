﻿

using ETicketAPI.Application.Abstractions.Service;
using System.Net.Mail;
using System.Net;
using Microsoft.Extensions.Configuration;

namespace ETicketAPI.Infrastructure.Service
{
    public class MailService : IMailService
    {
        private readonly IConfiguration _configuration;

        public MailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }



        public async Task SendMailAsync(string[] tos, string password, string body, string subject, bool bodyHtml = true)
        {
            SmtpClient client = new SmtpClient();
            client.Host = _configuration["MailSetting:host"];
            client.Port = Convert.ToInt32(_configuration["MailSetting:port"]);

            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential(_configuration["MailSetting:from"], _configuration["MailSetting:fromPassword"]);
            client.EnableSsl = true;

            //mail message
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(_configuration["MailSetting:from"]);
            foreach(var to in tos)
              mailMessage.To.Add(to);
            
            mailMessage.IsBodyHtml = bodyHtml;
            mailMessage.Body = body;
            mailMessage.Subject = subject;
            await client.SendMailAsync(mailMessage);

        }


        public async Task SendMailAsync(string to,string password,string body,string subject,bool bodyHtml=true)
        {
            SmtpClient client = new SmtpClient();
            client.Host = _configuration["MailSetting:host"];
            client.Port = Convert.ToInt32(_configuration["MailSetting:port"]);
          
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(_configuration["MailSetting:from"], _configuration["MailSetting:fromPassword"]);
                client.EnableSsl = true;

            //mail message
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(_configuration["MailSetting:from"]);
            mailMessage.To.Add(to);
            mailMessage.IsBodyHtml = bodyHtml;
            mailMessage.Body = body;
            mailMessage.Subject = subject;
           await client.SendMailAsync(mailMessage);

        }

    }
}
