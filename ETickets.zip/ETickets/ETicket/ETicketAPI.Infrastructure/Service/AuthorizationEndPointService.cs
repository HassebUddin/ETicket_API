﻿
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.Abstractions.Service.Configutration;
using ETicketAPI.Application.IRepositories.Web.EndPoints;
using ETicketAPI.Application.IRepositories.Web.Menus;
using ETicketAPI.Domain.Entities.Identity;
using ETicketAPI.Domain.Entities.Web;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Infrastructure.Service
{
    public class AuthorizationEndPointService : IAuthorizationEndPointService
    {
        private readonly IApplicationService _applicationService;

        private readonly IEndPointReadRepository  _endPointReadRepository;
        private readonly IEndPointWriteRepository _endPointWriteRepository;     

        private readonly IMenuReadRepository _menuReadRepository;   
        private readonly IMenuWriteRepository _menuWriteRepository;

        private readonly RoleManager<AppRole>  _roleManager;

        public AuthorizationEndPointService(IApplicationService applicationService, IEndPointReadRepository endPointReadRepository, IEndPointWriteRepository endPointWriteRepository,
            IMenuReadRepository menuReadRepository, IMenuWriteRepository menuWriteRepository, RoleManager<AppRole> roleManager)
        {
            _applicationService = applicationService;
            _endPointReadRepository = endPointReadRepository;
            _endPointWriteRepository = endPointWriteRepository;
            _menuReadRepository = menuReadRepository;
            _menuWriteRepository = menuWriteRepository;
            _roleManager = roleManager;
        }

        public async Task AssignRoleEndPointAsync(string[] role,string menu, string code,Type type)
        {

            var _menu =await _menuReadRepository.GetSingleAsync(x => x.Name == menu);
            if (_menu == null)
            {
                _menu = new()
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = menu

                };
                await _menuWriteRepository.AddAsync(_menu);
                await _menuWriteRepository.SaveChangeAsync();
            }

            var endpoint= _endPointReadRepository.Table.Include(x=>x.Menus).Include(x=>x.AppRoles).Where(x=>x.code==code && x.Menus.Name==menu).FirstOrDefault();
            if (endpoint == null)
            {
                var action = _applicationService.GetAuthorizationDefinionEndPoints(type).
                    FirstOrDefault(x => x.Name == menu)?.Actions.FirstOrDefault(x => x.Code == code);

                endpoint = new()
                {
                    code = action!.Code,
                    actionType = action.ActionType,
                    definition = action.Definition,
                    httpType = action.HttpType,
                    Id = Guid.NewGuid().ToString(),
                    Menus = _menu

                };

                await _endPointWriteRepository.AddAsync(endpoint);
                await _endPointWriteRepository.SaveChangeAsync();

                

            }
            //delete already roles
            foreach (var item in endpoint.AppRoles)
                endpoint.AppRoles.Remove(item);

            //add  user select role
            var approles = await _roleManager.Roles.Where(r => role.Contains(r.Name)).ToListAsync();
            foreach (var item in approles)
                endpoint.AppRoles.Add(item);

            await _endPointWriteRepository.SaveChangeAsync();
        }

        public async Task<List<string>> GetRoleToEndPointAsync(string menu, string code)
        {
           EntityEndPoint? _endpoint=await _endPointWriteRepository.Table.Include(x => x.Menus).Include(x => x.AppRoles)
                .FirstOrDefaultAsync(x => x.code == code && x.Menus.Name == menu);


            return _endpoint?.AppRoles.Select(r => r.Name).ToList()!;

        }
    }
}
