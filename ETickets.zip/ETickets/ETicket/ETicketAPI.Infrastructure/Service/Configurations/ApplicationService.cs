﻿

using ETicketAPI.Application.Abstractions.Service.Configutration;
using ETicketAPI.Application.CustomAttribute;
using ETicketAPI.Application.Dto.Configurations;
using ETicketAPI.Application.Enums;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using System.Reflection;
using Action = ETicketAPI.Application.Dto.Configurations.Action;

namespace ETicketAPI.Infrastructure.Service.Configurations
{
    public class ApplicationService :IApplicationService
    {
     public List<Menu> GetAuthorizationDefinionEndPoints(Type type)
        {
            var assembly = Assembly.GetAssembly(type);
            var controllers = assembly!.GetTypes().Where(x => x.IsAssignableTo(typeof(ControllerBase)));
            List<Menu> menus = new();
            if (controllers.Any())
            {
                foreach(var controller in controllers)
                {
                    var actions = controller.GetMethods().Where(x => x.IsDefined(typeof(AuthorizationDefinitionAttribute)));
                    if (actions.Any())
                    {
                       foreach(var action in actions)
                        {
                            var attributes = action.GetCustomAttributes(true);
                            if(attributes.Any())
                            {
                                Menu menu = null!;
                                var authorizationDefinitionAttribute = attributes.
                                    FirstOrDefault(x => x.GetType() == typeof(AuthorizationDefinitionAttribute)) as
                                       AuthorizationDefinitionAttribute;
                                if (!menus.Any(m => m.Name == authorizationDefinitionAttribute!.Menu))
                                {
                                    menu = new() { Name = authorizationDefinitionAttribute!.Menu };
                                    menus.Add(menu);
                                }    
                                else
                                    menu = menus.FirstOrDefault(m => m.Name == authorizationDefinitionAttribute!.Menu)!;

                                Action _action = new()
                                {
                                    ActionType = Enum.GetName(typeof(ActionType), authorizationDefinitionAttribute!.ActionType)!,
                                    Definition = authorizationDefinitionAttribute.Definition
                                };

                                var httpAttributes = attributes.FirstOrDefault(a => a.GetType().IsAssignableTo(typeof(HttpMethodAttribute))) as HttpMethodAttribute;
                                    if (httpAttributes != null)
                                    _action.HttpType = httpAttributes.HttpMethods.First();
                                else
                                    _action.HttpType = HttpMethods.Get;

                                _action.Code = $"{_action.ActionType},{_action.HttpType},{_action.Definition}".Replace(" ","");
                                menu.Actions.Add(_action);    
                            }
                        }
                    }
                  
                }
            }


            return menus;
        }
    }
}
