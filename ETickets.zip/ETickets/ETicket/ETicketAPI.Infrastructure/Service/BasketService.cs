﻿
using ETicketAPI.Application.Abstractions.Service;
using ETicketAPI.Application.IRepositories.Web.BasketItems;
using ETicketAPI.Application.IRepositories.Web.Baskets;
using ETicketAPI.Application.IRepositories.Web.Orders;
using ETicketAPI.Application.IRepositories.Web.Products;
using ETicketAPI.Application.ViewModel.Web.Basket;
using ETicketAPI.Domain.Entities.Identity;
using ETicketAPI.Domain.Entities.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ETicketAPI.Infrastructure.Service
{
    public class BasketService : IBasketService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly UserManager<AppUser> _userManager;

        private readonly IBasketReadRepository _baskeReadRepository;

        private readonly IBasketWriteRepository _basketWriteRepository;
        private readonly IBasketItemWriteRepository _baskeItemtWriteRepository;
        private readonly IBasketItemReadRepository _baskeItemtReadRepository;

        private readonly IOrderReadRepository _orderReadRepository;

        public BasketService(IHttpContextAccessor httpContextAccessor, UserManager<AppUser> userManager, 
            IOrderReadRepository orderReadRepository, IBasketItemWriteRepository baskeItemtWriteRepository
            , IBasketItemReadRepository baskeItemtReadRepository, IBasketWriteRepository basketWriteRepository, 
            IBasketReadRepository baskeReadRepository)
        {
            _httpContextAccessor = httpContextAccessor;
            _userManager = userManager;
            _orderReadRepository = orderReadRepository;
            _baskeItemtWriteRepository = baskeItemtWriteRepository;
            _baskeItemtReadRepository = baskeItemtReadRepository;
            _basketWriteRepository = basketWriteRepository;
            _baskeReadRepository = baskeReadRepository;
        }

        private async Task<Basket> ContextUser()
        {

            var username = "admin@gmail.com"; // _httpContextAccessor.HttpContext!.User.Identity!.Name;
            if(!string.IsNullOrEmpty(username))
            {
                var user = await _userManager.Users.Include(x => x.Baskets)
                    .FirstOrDefaultAsync(x => x.UserName == username);

                var _basket = from basket in user.Baskets
                              join order in _orderReadRepository.Table on basket.Id
                              equals order.Id into basketOrders
                              from order in basketOrders.DefaultIfEmpty()
                              select new
                              {
                                 Basket=basket,
                                 Order=order,
                              };

                Basket targetBasket = null;
                if (_basket.Any(x => x.Order is null))
                    targetBasket = _basket.FirstOrDefault(x => x.Order is null)!.Basket;
                else
                {
                    targetBasket = new();
                    user.Baskets.Add(targetBasket);
                }
                await _basketWriteRepository.SaveChangeAsync();
                return targetBasket;
            }
            throw new Exception("please login your self");
                  

        }

        public async Task AddItemToBasketAsync(CreateBasketViewModel basketItem)
        {
            Basket basket = await ContextUser();
                if (basket != null)
            {
            BasketItem _basketItem=    await _baskeItemtReadRepository.GetSingleAsync(bi => bi.BasketId == basket.Id &&
                bi.ProductId == basketItem.ProductId);
                if (_basketItem != null)
                    _basketItem.Quantity++;
                else
                 await   _baskeItemtWriteRepository.AddAsync(new()
                    {
                        BasketId = basket.Id,
                        ProductId = basketItem.ProductId,
                        Quantity = basketItem.Quantity,
                    });
                await _baskeItemtWriteRepository.SaveChangeAsync();
            }
            
        }

        public async Task<List<BasketItem>> GetBasketItemAsync()
        {
           var basket=await ContextUser();
          
           Basket result= await   _basketWriteRepository.Table.Include(x=>x.BasketItems).ThenInclude(x=>x.Products)
                    .FirstOrDefaultAsync(x=>x.Id== basket.Id)!;
            return result.BasketItems.ToList();
        }

        public async Task RemoveBasketItemAsync(string basketItemId)
        {
           BasketItem _basketItem=await _baskeItemtReadRepository.GetByIdAsync(basketItemId);
            if (_basketItem != null)
            {
                _baskeItemtWriteRepository.Remove(_basketItem);
                await _basketWriteRepository.SaveChangeAsync();

            }
        }

        public async Task UpateBasketItemAsync(UpdateBasketViewModel basketItem)
        {

            BasketItem _basketItem = await _baskeItemtReadRepository.GetByIdAsync(basketItem.BasketId);
                   
                if (_basketItem != null)
                {
                    _basketItem.Quantity = basketItem.Quantity;
                    await _baskeItemtWriteRepository.SaveChangeAsync();
                }
            
            
        }


        public Basket GetActiveUserBasket
        {
            get
            {
                Basket basket = ContextUser().Result;
                return basket;
            }
        }

    }
}
