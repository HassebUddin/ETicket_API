﻿

namespace ETicketAPI.Infrastructure.Enums
{
    public enum StorageType
    {
        local,
        AWS,
        Azure
    }
}
